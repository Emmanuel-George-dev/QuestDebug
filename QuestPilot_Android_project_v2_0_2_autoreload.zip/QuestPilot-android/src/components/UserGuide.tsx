import { ChevronDown } from "lucide-react";

interface Topic {
  title: string;
  body: string[];
}

const TOPICS: Topic[] = [
  {
    title: "Getting started",
    body: [
      "1. Settings → Zealy account → Connect Zealy, and log in once. Only the session is kept, encrypted on your phone. Your password is never stored.",
      "2. Sprints → Add, then enter the community's subdomain (the part in zealy.io/cw/<name>). Its tasks and sprint appear after the first sync.",
      "3. Settings → Permissions: allow notifications, exact alarms and full-screen alerts, and set the battery for QuestPilot to \"Don't optimize\" so alarms are never delayed.",
    ],
  },
  {
    title: "The Today page",
    body: [
      "Ready now = tasks you can claim right now. Next unlock = time until the next daily or weekly task opens. Live sprints = communities with a sprint running.",
      "\"Claimable now\" lists each task you can claim. Claim now opens that task inside the app's signed-in Zealy view.",
      "Daily claim autopilot opens the claim page a few seconds before a task unlocks, so you're ready at the unlock second. When the app is closed you get a full-screen alert instead.",
    ],
  },
  {
    title: "Claim run, Next and Auto-next",
    body: [
      "Start claim run → Open & next opens the claim screen with your whole list loaded. The Next (n) button moves to the following task, so you never have to go back to the home page.",
      "The Auto-next switch on the claim run card moves on by itself about 2 seconds after Zealy accepts a claim. The Next button always stays, whatever the switch says.",
      "If Auto-next doesn't move on, the app didn't recognise the claim. Tap Next, nothing is lost.",
      "While you work on one task, the next page already loads and fills in behind it, so Next only leaves you the Claim tap.",
    ],
  },
  {
    title: "Saved answers (autofill)",
    body: [
      "Tap \"Save for autofill\" on a task to store text and photos for it. When the claim page opens, the app fills them in for you.",
      "Every claim = the same answer is used each time. Use once = the answer is used for one claim, then marked used. Queue it again to use it later.",
      "If a fill fails, a banner at the top lets you copy the text or pick the saved photo.",
      "The app never taps Claim. You check the page and press Claim yourself.",
    ],
  },
  {
    title: "The Tasks page and its filters",
    body: [
      "All = every task. Recurring = every task that repeats (daily, weekly or monthly). Daily = tasks that reset every day at 00:00 UTC. Weekly = tasks that reset every Monday at 00:00 UTC.",
      "Limited = tasks with an end date. Twitter and Image = tasks by what you have to do (X tasks, photo uploads). In review = claims Zealy is still checking.",
      "The community chips under the filters show the tasks of one community only. Both work together: for example Daily + one community.",
    ],
  },
  {
    title: "Pre-click: Like, Repost, Follow, Visit",
    body: [
      "Tasks with an X post, an X profile or a website link get Pre-click buttons on their card and in Edit task. Each button opens that page inside the app. You tap Like, Repost or Follow on X yourself, the app never taps anything for you.",
      "A button turns into a check mark with the time once you pressed it. On daily and weekly tasks the marks reset with Zealy's reset, so you can do them again for the new day or week.",
      "Only tasks with a real X task get Like / Repost / Follow buttons. A photo-upload or quiz task never gets them, even if its page shows an X post.",
      "The same post or profile only gets one button, even when Zealy shows its link in several ways. Like 2, Like 3 only appear for really different posts.",
      "When you press a button and QuestPilot doesn't have Zealy's task id yet (or it is from yesterday on a daily task), it loads it from Zealy first, then marks the press. If the daily post changed, today's post opens. If nothing can be marked, the message says why.",
    ],
  },
  {
    title: "Where the links come from",
    body: [
      "QuestPilot loads each task's details from Zealy during sync (the same request Zealy's own task page makes): the post link, the profile and the website to visit. A full sync loads up to 40 tasks (20 per community), tasks unlocking within 24 hours first, then X and visit tasks.",
      "New tasks and tasks that just unlocked get their links within a few minutes, from the regular quest check.",
      "Daily and weekly tasks are loaded again after each reset, because their post can change every day.",
      "\"Waiting for the next sync\" = the task is in the queue and gets its links with the next sync. \"No link yet\" = QuestPilot couldn't find it yet: tap Find link and task id to load it right now.",
      "If Zealy refuses or sends nothing, QuestPilot tries again later by itself: after 30 minutes or 1 hour for the first three tries, then every 6 hours.",
    ],
  },
  {
    title: "Like / Repost close timer (Debug)",
    body: [
      "Debug → Links and X → Close after: the like / repost page closes by itself this many seconds after it loaded. 1 to 10 seconds shows the X page for that long.",
      "0 = load in the background, nothing is shown. The X page loads hidden behind the app (on the Zealy task page and on the task card buttons), stays open until it loaded (1.6 to 4 seconds) and then closes the normal way, so Zealy still sees you went to X and came back.",
    ],
  },
  {
    title: "Logged-in sites",
    body: [
      "Settings → Logged-in sites lists the sites where you are really logged in inside QuestPilot (X, Facebook, Google, Reddit, ... are checked by their login cookie). Just opening a site is not a login and no longer shows there.",
      "Discord and Telegram Web keep their login inside the page, so QuestPilot can't check them: they show as \"Visited\".",
    ],
  },
  {
    title: "Several tasks unlocking together",
    body: [
      "Tasks that unlock at the exact same second are grouped into one alert and one claim screen. Use Next to walk through them.",
      "Give them the same fixed reset time so they unlock together. If their times differ by even a few seconds, they get separate alerts.",
    ],
  },
  {
    title: "The Sprints page",
    body: [
      "Sprint ends = live countdown. Tasks done / total = how many of the community's tasks you've completed out of all the app found. XP earned = your XP in that community from Zealy; if Zealy didn't provide it, the app's own tally.",
      "The bar shows one-time tasks done. Task adds one by hand, Quests opens the questboard and Board opens the leaderboard.",
      "The Zealy icon at the top opens zealy.io so you can find new sprints. The search box filters your sprints by name, link or prize.",
      "The circular arrow on a card syncs only that community. Sync at the top syncs all of them.",
    ],
  },
  {
    title: "Alerts and notifications",
    body: [
      "You get alerts for unlocks, deadlines, new quests (Watchlist) and sprints: one 24 hours before a sprint ends and one when it ends.",
      "Sprint alarms are set on the phone from the saved end date, so they fire even if you're offline or a sync hasn't run. If a sync finds a new end date, the alarm is rescheduled.",
      "Telegram push (Settings) sends every alert to your Telegram too. Export calendar adds unlocks and deadlines to your phone's calendar.",
      "Each alert shows a time at the end, in your phone's time zone: (Zealy 5:12 PM) is the time Zealy gave for the message or the new task; (detected 5:15 PM) means Zealy gave no time and this is when QuestPilot first saw it. Earlier days show the date too.",
    ],
  },
  {
    title: "Watchlist and Zealy Monitor",
    body: [
      "Settings → Watchlist & Zealy Monitor checks up to 3 communities every 3 minutes for new and newly unlocked quests, even for communities you haven't joined.",
    ],
  },
  {
    title: "Good to know",
    body: [
      "Statuses only come from a successful Zealy sync. Opening a task never changes its status. Daily quests reset at 00:00 UTC, weekly quests on Monday 00:00 UTC.",
      "A daily or weekly task you already claimed counts down to the next reset, and shows up in Ready now and in the claim run again once the reset passed.",
      "Under a countdown a short line says why the app shows that time (for example \"Zealy reports it claimed: next reset after that\" or \"Zealy: locked by a date condition\"). If it looks wrong, open the task (Edit) and tap Copy task data to send what the app knows about it.",
      "A task you added by hand from a Zealy link resets like on Zealy (00:00 UTC), not 24 hours after you claimed it. Once its community syncs, it becomes the synced task with Zealy's status and links.",
      "Requests you wait for (the claim status check, unlock re-checks, Find link, Sync now) go before background syncing, so they are never stuck behind it.",
      "Zealy's terms may not allow automated access. Keep the Claim tap manual, use your own varied answers, and respect each community's rules. You use the app at your own risk.",
    ],
  },
  {
    title: "Troubleshooting",
    body: [
      "Nothing syncs: Settings → Sync now, or Reconnect Zealy if the session expired.",
      "Alerts arrive late: set the battery to \"Don't optimize\" for QuestPilot and allow exact alarms.",
      "Autofill didn't fill: use the banner to copy your text or attach the saved photo. Zealy may have changed its page.",
      "XP doesn't match Zealy: sync again. If the app can't read it from Zealy it shows its own tally.",
      "A task has no Pre-click button: open the task card and tap Find link and task id. Debug → Event log shows a \"task details: N loaded, M waiting for the next sync, K failed\" line after each sync.",
      "Something feels slow: Debug → Event log, the \"perf\" lines show how long opening a page and loading it took.",
    ],
  },
];

/** Plain-language guide. Each topic opens and closes on tap. */
export function UserGuide() {
  return (
    <div className="divide-y divide-border/60 rounded-xl border border-card-border bg-card" data-testid="user-guide">
      {TOPICS.map((t) => (
        <details key={t.title} className="group px-3.5 py-3">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-3 text-sm font-semibold [&::-webkit-details-marker]:hidden">
            {t.title}
            <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-180" />
          </summary>
          <div className="mt-2 space-y-2 text-xs leading-relaxed text-muted-foreground">
            {t.body.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        </details>
      ))}
    </div>
  );
}
