package io.questpilot.app

import android.app.Activity
import android.app.Application
import android.os.Bundle
import java.util.concurrent.Executors

class QuestPilotApp : Application() {
    companion object {
        @Volatile private var started = 0
        val isForeground get() = started > 0
        @Volatile var ctx: android.content.Context? = null
    }

    override fun onCreate() {
        super.onCreate()
        ctx = applicationContext
        State.processStartAt = System.currentTimeMillis()
        EventLog.init(this)
        State.init(this)
        SessionStore.loadAuthMode(this)
        DbStore.init(this)
        Notifications.createChannels(this)
        DevTools.createChannel(this)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(a: Activity) { started++ }
            override fun onActivityStopped(a: Activity) { started = (started - 1).coerceAtLeast(0) }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityResumed(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
        Executors.newSingleThreadExecutor().execute {
            // v2.0.2: a manual run "open" flag left by a stopped app no longer holds the claim run back
            try { ManualRun.clearStale() } catch (_: Exception) {}
            try { AlarmScheduler.rescheduleAll(this) } catch (_: Exception) {}
            try { SavedPhotos.gc(this) } catch (_: Exception) {}
            // Test quests never live in the real data; remove any an older build left there.
            try { DbStore.purgeTestData() } catch (_: Exception) {}
            // v2.4.7 Fix 4: duplicate Pre-click links saved by older versions become one
            try { PageLinks.mergeStored() } catch (_: Exception) {}
            // v2.0.0: no Like / Repost buttons on tasks without an X task
            try { PageLinks.cleanNonX(this) } catch (_: Exception) {}
            if (!DevTools.ENABLED) try { DevTools.clear(this) } catch (_: Exception) {}
        }
    }
}
