package io.questpilot.app

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.0.2 manual claim run. Stored in prefs.manualRun = { ids, auto, open, openedAt }.
 *   ids      task ids in run order (any community, locked or not); written by the app UI
 *   auto     open the run by itself 10 s before the first unlock (default on); written by the app UI
 *   open     the run screen is open; written by the native side only
 *   openedAt when it was opened (ms) or null; written by the native side only
 *
 * The unlock time of every task is quest.unlockAt, computed by UnlockClock (daily / weekly / monthly reset,
 * Zealy date condition, openAt), the same value the claim run alarms use. The automatic open is one more
 * stage ("manual") of AlarmScheduler.rescheduleAll, so it follows every sync, survives reboots and is
 * re-armed by verify() like the other alarms.
 */
object ManualRun {
    const val PREF = "manualRun"
    /** The screen opens this long before the first unlock (same moment as the claim run's countdown screen). */
    const val LEAD_MS = 10_000L
    /** The normal claim run screen is held back from this long before an automatic open until the run closes. */
    private const val GUARD_MS = 15_000L
    private const val REQ = 0x4d52 // "MR"
    const val NOTIF_ID = 7

    fun state(db: JSONObject): JSONObject? = DbStore.prefs(db).optJSONObject(PREF)

    fun ids(db: JSONObject): List<Int> {
        val a = state(db)?.optJSONArray("ids") ?: return emptyList()
        return (0 until a.length()).map { a.optInt(it) }.filter { it > 0 }.distinct()
    }

    fun auto(db: JSONObject): Boolean = state(db)?.optBoolean("auto", true) ?: true

    /** The run screen is open in this process. */
    fun isOpen(): Boolean = ManualRunActivity.openCount > 0

    /** Unlock time of a quest as stored by UnlockClock: >0 = moment, 0 = open now, null = locked / unknown. */
    fun unlockOf(q: JSONObject): Long? = if (!q.has("unlockAt") || q.isNull("unlockAt")) null else q.optLong("unlockAt")

    /** Next automatic open: the earliest unlock among the run's tasks that is still more than LEAD_MS away. */
    class Plan(val basis: Long, val fireAt: Long, val quests: List<JSONObject>)

    fun plan(db: JSONObject, now: Long = System.currentTimeMillis()): Plan? {
        if (!auto(db)) return null
        val qs = ids(db).mapNotNull { DbStore.quest(db, it) }
        val t = qs.mapNotNull { unlockOf(it) }.filter { it - LEAD_MS > now }.minOrNull() ?: return null
        return Plan(t, t - LEAD_MS, qs.filter { unlockOf(it)?.let { u -> u / 1000 == t / 1000 } == true })
    }

    /** Task ids the manual run takes over from the normal claim run (auto on): their fs10 / claim / ready stages are skipped. */
    fun handledIds(db: JSONObject): Set<Int> = if (auto(db)) ids(db).toSet() else emptySet()

    /**
     * The normal claim run screen must not open now: the run screen is open, or it opens by itself within
     * GUARD_MS. Same rule as manualRunHolds() in src/lib/quest.ts.
     */
    fun holdsClaimRun(db: JSONObject, now: Long = System.currentTimeMillis()): Boolean {
        if (isOpen()) return true
        // plan(now - GUARD_MS) only returns opens after now - GUARD_MS: held from GUARD_MS before to GUARD_MS after it
        val p = plan(db, now - GUARD_MS) ?: return false
        return p.fireAt <= now + GUARD_MS
    }

    private fun write(f: (JSONObject) -> Unit) {
        DbStore.mutate { d ->
            val st = d.getJSONObject("settings")
            val p = st.optJSONObject("prefs") ?: JSONObject().also { st.put("prefs", it) }
            val s = p.optJSONObject(PREF) ?: JSONObject().put("ids", JSONArray()).put("auto", true)
                .put("open", false).put("openedAt", JSONObject.NULL)
            f(s)
            p.put(PREF, s)
        }
    }

    fun setIds(ids: List<Int>) = write { it.put("ids", JSONArray(ids.distinct())) }

    fun markOpen(open: Boolean) = write { s ->
        s.put("open", open)
        s.put("openedAt", if (open) System.currentTimeMillis() else JSONObject.NULL)
    }

    /** At app start: an "open" flag left by a stopped app is cleared, so the claim run is not held back. */
    fun clearStale() {
        val s = state(DbStore.read()) ?: return
        if (s.optBoolean("open") && !isOpen()) {
            markOpen(false)
            EventLog.add("manual", "manual run flag left by a stopped app cleared")
        }
    }

    /** "Start": open the run screen now. */
    fun start(ctx: Context, ids: List<Int>? = null) {
        if (ids != null) setIds(ids)
        EventLog.add("manual", "manual run started by hand (${ids(DbStore.read()).size} task(s))")
        ctx.startActivity(Intent(ctx, ManualRunActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** The "manual" alarm fired (10 s before [basis]): open the screen, or a full-screen notification in the background. */
    fun fire(ctx: Context, basis: Long, unlocking: List<JSONObject>) {
        val db = DbStore.read()
        if (!auto(db) || ids(db).isEmpty()) return
        val title = if (unlocking.size == 1) unlocking[0].optString("title") else "${unlocking.size} tasks"
        if (isOpen()) { EventLog.add("manual", "manual run already open for $title"); return }
        EventLog.add("manual", "manual run opens by itself: $title unlocks ${DbStore.localClock(basis)}")
        val open = Intent(ctx, ManualRunActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (QuestPilotApp.isForeground || ClaimActivity.openCount > 0) { ctx.startActivity(open); return }
        if (!Notifications.canPost(ctx)) { try { ctx.startActivity(open) } catch (_: Exception) {}; return }
        val p = PendingIntent.getActivity(ctx, REQ, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = ids(db).size
        val b = NotificationCompat.Builder(ctx, Notifications.CH_CLAIM)
            .setSmallIcon(R.drawable.ic_stat_qp)
            .setContentTitle("Manual run: $title unlocks in 10 s")
            .setContentText("$n task${if (n == 1) "" else "s"} in the run · tap to open")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setTimeoutAfter(15 * 60_000L)
            .setContentIntent(p)
            .setFullScreenIntent(p, true)
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, b.build())
    }

    fun cancelNotification(ctx: Context) = ctx.getSystemService(NotificationManager::class.java)?.cancel(NOTIF_ID)
}
