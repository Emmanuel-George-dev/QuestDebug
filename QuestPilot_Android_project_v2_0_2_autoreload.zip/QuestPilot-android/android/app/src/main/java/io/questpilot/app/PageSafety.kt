package io.questpilot.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceResponse
import org.json.JSONArray
import org.json.JSONObject

/**
 * v2.0.2 (safety update): Cloudflare / bot-protection pages shown inside a WebView.
 *
 * Detection only. Nothing here blocks, bypasses or solves a challenge: /cdn-cgi/ scripts, the Turnstile frame and
 * the cf_clearance cookie all load normally. The screen that sees a challenge brings that page to the front, shows
 * "Human verification required" and stops its own extra work (further page loads, claim releases) until it is
 * gone. While a challenge is on screen, the app's automatic and priority Zealy API requests don't go out
 * (ZealyGate), so nothing else hits Zealy while you solve it.
 */
object CfChallenge {
    /** Interstitial titles (same spirit as Zealy403's regex, narrowed to page titles). */
    private val TITLE_RX = Regex("(?i)^\\s*(just a moment|attention required|checking your browser|please wait|one more step|verify you are human|security check)")
    /** URLs that only an interstitial / challenge navigation has. */
    private val URL_RX = Regex("(?i)/cdn-cgi/challenge|__cf_chl_|cf_chl_rt|cf_chl_f_tk|challenge-platform/h/")
    /** Hosts of the challenge frames: never blocked, never opened as an outside link. */
    private val CHALLENGE_HOSTS = setOf("challenges.cloudflare.com", "hcaptcha.com", "newassets.hcaptcha.com", "js.hcaptcha.com", "recaptcha.net", "www.recaptcha.net")

    /** Same markers as Zealy403.isChallenge, read from the page itself (main frame). Returns "1" / "0". */
    const val DETECT_JS = "(function(){try{var t=(document.title||'');" +
        "if(/^\\s*(just a moment|attention required|checking your browser|verify you are human|security check)/i.test(t))return '1';" +
        "if(window._cf_chl_opt||document.getElementById('challenge-form')||document.getElementById('challenge-running')||" +
        "document.getElementById('cf-challenge-running')||document.querySelector('#challenge-stage,#challenge-body-text,.cf-browser-verification'))return '1';" +
        "var h=location.pathname+location.search;if(/\\/cdn-cgi\\/challenge|__cf_chl_/i.test(h))return '1';" +
        "var s=document.querySelector('script[src*=\"/cdn-cgi/challenge-platform/h/\"]');" +
        "if(s&&document.body&&document.body.innerText.length<1500&&/verif|human|moment|browser|security/i.test(document.body.innerText))return '1';" +
        "return '0';}catch(e){return '0';}})()"

    fun isChallengeTitle(title: String?) = title != null && TITLE_RX.containsMatchIn(title)

    fun isChallengeUrl(url: String?) = url != null && URL_RX.containsMatchIn(url)

    /** A challenge frame / script that must load untouched (never treated as an outside link). */
    fun isChallengeResource(u: Uri?): Boolean {
        u ?: return false
        val host = u.host?.lowercase() ?: return false
        if (host in CHALLENGE_HOSTS || host.endsWith(".hcaptcha.com")) return true
        if (host == "www.google.com" && (u.path ?: "").startsWith("/recaptcha")) return true
        return (u.path ?: "").startsWith("/cdn-cgi/")
    }

    /** Cloudflare marks challenge answers with `cf-mitigated: challenge`. */
    fun isMitigated(r: WebResourceResponse?): Boolean {
        val h = r?.responseHeaders ?: return false
        return h.entries.any { it.key.equals("cf-mitigated", true) && it.value.contains("challenge", true) }
    }

    fun parse(res: String?) = res?.trim('"') == "1"

    // ---- shared state: one challenge visible anywhere pauses the app's own extra Zealy requests ----
    private val visible = java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<String, Boolean>())
    @Volatile private var clearedAt = 0L
    /** After the last challenge is solved, extra requests stay paused this long (the clearance cookie settles). */
    private const val AFTER_CLEAR_MS = 15_000L

    fun shown(owner: String, where: String) {
        if (visible.add(owner)) try { EventLog.add("challenge", "human verification page shown ($where): extra Zealy requests paused") } catch (_: Exception) {}
    }

    fun cleared(owner: String, where: String) {
        if (visible.remove(owner)) {
            clearedAt = System.currentTimeMillis()
            try { EventLog.add("challenge", "human verification done ($where): resuming") } catch (_: Exception) {}
        }
    }

    /** true = a challenge is on screen (or was solved moments ago): automatic / priority Zealy requests wait. */
    fun blocking(): Boolean = visible.isNotEmpty() || System.currentTimeMillis() - clearedAt < AFTER_CLEAR_MS
}

/**
 * v2.0.2 (safety update): "soft update" of a Zealy page that is already open, for the unlock / reset second.
 * Instead of reloading the whole page (HTML + every script + every API call), the page is told it was
 * shown again (focus + visibilitychange, a same-URL history.replaceState + popstate), which makes Zealy's own
 * data layer fetch the quest again. Nothing is clicked. [PROBE_JS] only reads whether the Claim button is there.
 */
object SoftUpdate {
    const val SOFT_JS = "(function(){try{" +
        "try{document.dispatchEvent(new Event('visibilitychange'));}catch(e){}" +
        "try{window.dispatchEvent(new Event('focus'));}catch(e){}" +
        "try{window.dispatchEvent(new Event('online'));}catch(e){}" +
        "try{var st=history.state;history.replaceState(st,'',location.href);window.dispatchEvent(new PopStateEvent('popstate',{state:st}));}catch(e){}" +
        "return '1';}catch(e){return '0';}})()"

    /** {"claim":bool,"locked":bool}: a visible Claim button (enabled or not: it may wait for the task box). Reads only. */
    const val PROBE_JS = "(function(){try{" +
        "var bs=[].slice.call(document.querySelectorAll('button,[role=button]'));" +
        "var claim=bs.some(function(b){var t=(b.innerText||b.textContent||'').trim();return /^claim\\b/i.test(t)&&b.getClientRects().length>0;});" +
        "var tx=(document.body&&document.body.innerText||'').slice(0,30000);" +
        "var locked=/\\b(unlocks? in|locked|available in|resets? in|come back in|opens in)\\b/i.test(tx);" +
        "return JSON.stringify({claim:claim,locked:locked});}catch(e){return '{}';}})()"

    class Probe(val claim: Boolean, val locked: Boolean)

    fun parse(res: String?): Probe {
        val s = try {
            val raw = res ?: return Probe(false, false)
            // evaluateJavascript returns the string JSON-encoded
            if (raw.startsWith("\"")) org.json.JSONTokener(raw).nextValue() as? String ?: "{}" else raw
        } catch (_: Exception) { "{}" }
        val o = try { JSONObject(s) } catch (_: Exception) { JSONObject() }
        return Probe(o.optBoolean("claim"), o.optBoolean("locked"))
    }
}

/**
 * v2.0.2 (safety update): native status check at the unlock / reset second, through the existing Zealy API path
 * (questboard of the quest's community, same request a sync makes, through ZealyGate: spaced, capped). One
 * request per community every [SHARE_MS]: tabs of the same community unlocking together share one answer.
 * Never sent while a pause or a human-verification page is active. A 429 or a bot-protection answer goes to
 * Backoff exactly like the monitors do.
 */
object UnlockStatus {
    const val OPEN = "open"
    const val LOCKED = "locked"
    const val CLAIMED = "claimed"
    const val UNKNOWN = "unknown"
    private const val SHARE_MS = 15_000L
    private val main = Handler(Looper.getMainLooper())
    private val exec = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val cache = HashMap<String, Pair<Long, JSONArray?>>() // sub -> (at, modules)

    /** [manual] = send through the manual lane (the manual run screen: its automatic lane is closed on purpose). */
    fun check(ctx: Context, q: JSONObject, manual: Boolean, cb: (String) -> Unit) {
        val zid = q.optString("zealyId").takeIf { it.isNotEmpty() && !q.isNull("zealyId") }
        val sub = try { DbStore.community(DbStore.read(), q.optInt("communityId"))?.optString("subdomain") } catch (_: Exception) { null }
        if (zid == null || sub.isNullOrEmpty() || q.optString("source") == "test" || DevTools.isTestId(q.optInt("id"))) { cb(UNKNOWN); return }
        if (State.paused() || CfChallenge.blocking()) { cb(UNKNOWN); return }
        val app = ctx.applicationContext
        exec.execute {
            val out = try {
                val now = System.currentTimeMillis()
                val hit = synchronized(cache) { cache[sub]?.takeIf { now - it.first < SHARE_MS } }
                val modules = if (hit != null) hit.second else {
                    val r = if (manual) ZealyGate.manual { ZealyApi.questboard(app, sub) } else ZealyGate.priority { ZealyApi.questboard(app, sub) }
                    when {
                        r.code == 429 -> { Backoff.hit(app, 429, "rate limit (429) on unlock check"); EventLog.add("manual", Zealy403.line(r, "unlock check: rate limited")) }
                        Zealy403.isChallenge(r) -> { Backoff.hit(app, 403, "blocked: bot-protection page (403)"); EventLog.add("manual", Zealy403.line(r, "unlock check: bot-protection page")) }
                    }
                    val m = if (r.ok) ZealyApi.modules(r) else null
                    if (!r.skipped) synchronized(cache) { cache[sub] = System.currentTimeMillis() to m }
                    m
                }
                val zq = modules?.let { find(it, zid) }
                when {
                    zq == null -> UNKNOWN
                    zq.optBoolean("claimed") || zq.optBoolean("completed") -> CLAIMED
                    zq.optBoolean("locked") -> LOCKED
                    else -> OPEN
                }
            } catch (_: Exception) { UNKNOWN }
            main.post { cb(out) }
        }
    }

    /** The quest object with this id anywhere in the questboard answer. */
    private fun find(node: Any?, zid: String, depth: Int = 0): JSONObject? {
        if (depth > 6) return null
        when (node) {
            is JSONArray -> for (i in 0 until node.length()) find(node.opt(i), zid, depth + 1)?.let { return it }
            is JSONObject -> {
                if (node.optString("id") == zid && (node.has("locked") || node.has("name"))) return node
                val keys = node.keys()
                while (keys.hasNext()) {
                    val v = node.opt(keys.next())
                    if (v is JSONArray || v is JSONObject) find(v, zid, depth + 1)?.let { return it }
                }
            }
        }
        return null
    }
}
