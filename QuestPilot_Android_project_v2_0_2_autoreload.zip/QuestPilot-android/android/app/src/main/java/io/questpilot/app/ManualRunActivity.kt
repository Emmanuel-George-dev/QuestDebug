package io.questpilot.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.MutableContextWrapper
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * v2.0.2: manual claim run. One tab per task of prefs.manualRun.ids, in that order, each with its own Zealy
 * WebView (chip strip + Prev / Next). Switching tabs only changes which page is visible: nothing closes or reloads.
 * Pages load exactly like the normal claim page (nothing blocked).
 *
 * Safety update (still 2.0.2):
 *  - Strictly sequential page work. Every WebView is built at open, but only one page operation (load, unlock
 *    soft update, reload) runs at a time, in a single queue: Tab 1 loads -> Tab 1 finished -> Tab 2 loads ...
 *    The next one starts CHAIN_GAP_MS after the previous page's onPageFinished (or OP_TIMEOUT_MS at the latest).
 *    No timer starts the other tabs, and tabs unlocking in the same second are not started together: their unlock
 *    work is queued (in tab order) and runs one after the other.
 *  - Unlock / reset second: a page that is already open gets a soft update first (focus + visibilitychange +
 *    same-URL popstate, nothing clicked) and one shared native status check (questboard, through ZealyGate). When
 *    the Claim button still isn't there after 4 s (daily / weekly reset) or 3.5 s (timed "unlocks in" task) the
 *    page is fully reloaded. A locked tab that unlocks within 30 s of the open loads once at its unlock second; the
 *    first timed task of such a group is pre-warmed (loaded) 10 s before its unlock.
 *  - Cloudflare / human verification on a tab: that tab is brought to the front with a message, and both the page
 *    queue and the claim queue pause until it is solved (the challenge itself loads untouched).
 *
 * Auto reload (setting "manualAutoReload", on by default, read each time it matters): a locked / resetting tab is
 * refreshed REFRESH_LEAD_MS (3 s) before its unlock: loaded when it wasn't loaded yet, reloaded otherwise, always
 * through the page queue. With the setting off nothing reloads by itself around the unlock (the soft update, which
 * clicks nothing, still runs); you reload with the icon in the bottom bar, which is there in both modes.
 *
 * Claim queue: every page's own claim request (same URL test as ClaimActivity.CLAIM_HOOK_JS) is held by
 * RUN_HOOK_JS until no other claim of this run is in flight; then it goes out by itself. A claim tapped while the
 * queue is idle (the previous one already answered) goes out at once; only claims that stacked up behind another
 * one are released STACKED_GAP_MS apart. Every answer shows at the top on any tab (resultBanner). A claim that never answers frees the queue after 30 s. After a 429 the next claim waits
 * 35 s (50 s for another 429 within 60 s). Nothing is tapped for you: the hook only delays the request your own tap
 * made. Autofill (saved content), X links (65% sheet) and the session work as on the claim screen. The app's own
 * background Zealy requests wait while the run is open (ZealyGate).
 */
class ManualRunActivity : Activity(), LinkBannerHost {
    companion object {
        @Volatile var openCount = 0
        /**
         * Gap before a claim that was tapped while another one was still waiting / in flight (stacked), counted from
         * the previous answer. A claim tapped on an idle queue (you waited for the previous answer) goes out at once.
         */
        private const val STACKED_GAP_MS = 1_500L
        /** Claim result banner at the top: shown this long (or until the next result replaces it). */
        private const val RESULT_BANNER_MS = 2_800L
        /** Dark page colour used while a tab's page hasn't drawn yet (matches Zealy's dark theme). */
        private const val PAGE_BG = "#0f0f12"
        private const val CLAIM_TIMEOUT_MS = 30_000L
        /** Sequential loading: the next page operation starts this long after the previous page finished. */
        private const val CHAIN_GAP_MS = 600L
        /** A page that never reports "finished" frees the page queue after this. */
        private const val OP_TIMEOUT_MS = 25_000L
        /** Timed locked task (first of its unlock group only): its page starts loading this long before the unlock. */
        private const val PREWARM_MS = 10_000L
        /** Tabs whose unlock times are this close count as one unlock group (only the first one is pre-warmed). */
        private const val UNLOCK_GROUP_MS = 5_000L
        /** Soft update: how long to wait for the Claim button before the full reload. */
        private const val SOFT_WAIT_RECURRING_MS = 4_000L
        private const val SOFT_WAIT_TIMED_MS = 3_500L
        /** Native check said "still locked" at the deadline: one more soft try of this length, then the reload. */
        private const val SOFT_EXTEND_MS = 3_000L
        private const val SOFT_POLL_MS = 500L
        /** Auto reload: a locked tab is refreshed this long (3 s) before its unlock (setting manualAutoReload). */
        private const val REFRESH_LEAD_MS = 3_000L
        /** While a human-verification page is up: how often it is re-read to notice it was solved. */
        private const val CHALLENGE_POLL_MS = 2_500L
        /** Same as the claim screen: reload + fill again when the task box is missing, within 90 s of the unlock. */
        private const val FILL_MAX_RETRIES = 2
        private const val FILL_RETRY_WINDOW_MS = 90_000L
        /** A locked tab whose unlock is this close when the run opens loads once, at the unlock second (no load + reload). */
        private const val LOAD_AT_UNLOCK_WITHIN_MS = 30_000L
        /** After a 429 (Zealy: too many requests) the next claim waits this long ... */
        private const val COOLDOWN_MS = 35_000L
        /** ... and this long when another 429 came within the last 60 s. */
        private const val COOLDOWN_REPEAT_MS = 50_000L
        private val ZEALY_ORIGINS = setOf("https://zealy.io", "https://www.zealy.io")

        /** Holds the page's claim request (fetch / XHR) until the native queue says go. Same URL test as CLAIM_HOOK_JS. */
        val RUN_HOOK_JS = """
(function(){if(window.__qpRunHook)return;window.__qpRunHook=1;
var RE=/zealy\.io\/[^?#]*\/claim(?:[\/?#]|$)/i,W=/^(POST|PUT|PATCH)$/i,seq=0,held={};
function abs(u){try{return new URL(u,location.href).href;}catch(e){return String(u||'');}}
function done(id,st,t){try{QPRun.done(id,st|0,(t||'').slice(0,2000));}catch(e){}}
window.__qpRunGo=function(id){var f=held[id];if(!f)return false;delete held[id];f();return true;};
var of=window.fetch;
if(of)window.fetch=function(i,n){var self=this,args=arguments;try{var u=abs(typeof i==='string'?i:(i&&i.url)||'');var m=(n&&n.method)||(i&&typeof i!=='string'&&i.method)||'GET';
if(window.QPRun&&RE.test(u)&&W.test(m)){var id=(++seq)+'-'+Date.now();return new Promise(function(res,rej){
held[id]=function(){var p;try{p=of.apply(self,args);}catch(e){done(id,0,'');rej(e);return;}
p.then(function(r){try{r.clone().text().then(function(t){done(id,r.status,t);},function(){done(id,r.status,'');});}catch(e){done(id,r.status,'');}res(r);},function(e){done(id,0,'');rej(e);});};
try{QPRun.request(id,u);}catch(e){window.__qpRunGo(id);}});}}catch(e){}return of.apply(this,arguments);};
var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open=function(m,u){this.__qprm=m;this.__qpru=abs(u);return xo.apply(this,arguments);};
XMLHttpRequest.prototype.send=function(){var x=this,args=arguments;try{if(window.QPRun&&RE.test(x.__qpru||'')&&W.test(x.__qprm||'')){var id=(++seq)+'-'+Date.now();
held[id]=function(){x.addEventListener('loadend',function(){var t='';try{t=(x.responseType===''||x.responseType==='text')?x.responseText:'';}catch(e){}done(id,x.status||0,t);});xs.apply(x,args);};
try{QPRun.request(id,x.__qpru);}catch(e){window.__qpRunGo(id);}return;}}catch(e){}return xs.apply(this,arguments);};
})();
""".trimIndent()
    }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var root: FrameLayout
    private lateinit var stack: FrameLayout
    private lateinit var chipRow: LinearLayout
    private lateinit var chipScroll: HorizontalScrollView
    private lateinit var prevBtn: Button
    private lateinit var nextBtn: Button
    private lateinit var reloadBtn: ImageButton
    private lateinit var banner: LinearLayout
    private lateinit var bannerText: TextView
    private var bannerLink: String? = null
    private lateinit var links: LinkOverlay
    private val tabs = mutableListOf<Tab>()
    private var current = 0
    private val touchedSubs = mutableSetOf<String>()
    private val zHook by lazy { ZealyHookBridge.script(try { DbStore.pref(DbStore.read(), "debugZealyRecorder", false) } catch (_: Exception) { false }) }
    private val fillJs by lazy { Autofill.script(this) }
    private val fillSelectors by lazy { Autofill.selectors(this) }
    /**
     * Same selectors as the claim screen, plus: fill each box only once React has wired it (requireReact), and
     * keep looking for up to 45 s (several pages load at once, so a task box can take longer than the usual 10 s).
     */
    private val fillCfg by lazy {
        try { JSONObject(fillSelectors).put("requireReact", true).put("retryMs", 45_000).put("unwiredAfterMs", 5_000).toString() }
        catch (_: Exception) { fillSelectors }
    }
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var closed = false
    /** The tab whose link opened the X sheet: its page gets the focus events and the auto-paste. */
    private var sheetTab: Tab? = null
    private lateinit var cfBanner: TextView
    private lateinit var resultBanner: TextView
    private val hideResult = Runnable { if (::resultBanner.isInitialized) resultBanner.animate().alpha(0f).setDuration(180).withEndAction { resultBanner.visibility = View.GONE }.start() }

    // ---------- page queue: one load / unlock update / reload at a time (main thread only) ----------
    private enum class OpKind { LOAD, UNLOCK, RELOAD, REFRESH }
    private inner class PageOp(val tab: Tab, val kind: OpKind, val reason: String) {
        /** The op ends at this tab's next onPageFinished (false while a soft update is being tried). */
        var waitingForPage = false
        var extended = false
        var native = UnlockStatus.UNKNOWN
        var softStartedAt = 0L
    }
    private val ops = ArrayList<PageOp>()
    private var activeOp: PageOp? = null
    private var opTimeout: Runnable? = null
    private val runOpsRunnable = Runnable { runOps() }
    /** A tab showing a Cloudflare / human-verification page: page queue + claim queue pause while set. */
    private var challengeTab: Tab? = null
    private val challengeKey = "manual-run-" + System.identityHashCode(this)

    // ---------- claim queue (main thread only) ----------
    /** [stacked] = tapped while another claim was waiting or in flight: released STACKED_GAP_MS after that answer. */
    private class Req(val tab: Tab, val id: String, val stacked: Boolean)
    private val waiting = ArrayDeque<Req>()
    private var inFlight: Req? = null
    private var lastDoneAt = 0L
    /** Zealy answered 429: no claim goes out before this (ms). */
    private var cooldownUntil = 0L
    private var last429At = 0L
    private val pumpRunnable = Runnable { pump() }
    private var timeoutRunnable: Runnable? = null

    inner class Tab(val q: JSONObject, val index: Int) {
        val questId = q.optInt("id")
        val title: String = q.optString("title").ifEmpty { "Task $questId" }
        private val comm = DbStore.community(DbStore.read(), q.optInt("communityId"))
        val sub: String = comm?.optString("subdomain") ?: ""
        val commName: String = comm?.optString("name") ?: ""
        val url: String = q.optString("url").ifEmpty { if (sub.isNotEmpty()) "https://zealy.io/cw/$sub/questboard" else "https://zealy.io" }
        val unlockAt: Long = if (q.isNull("unlockAt")) 0L else q.optLong("unlockAt")
        /** daily / weekly / monthly reset (recurring) or a one-time task locked until a date */
        val recurring: Boolean = q.optString("recurrence", "once") != "once"
        val holder = FrameLayout(this@ManualRunActivity)
        /** Dark Zealy-style page area with a small spinner, until the page draws (no full-screen text). */
        val placeholder = FrameLayout(this@ManualRunActivity)
        var web: WebView? = null
        var loaded = false
        var loadedBeforeUnlock = false
        var claim = ""            // "", waiting, claiming, claimed, in review, failed, no answer
        var job: AutofillJob? = null
        var fillPending = false
        var filled = false
        var fillRetries = 0
        /** Saved text + photos as the fill script wants them, built on the io thread while the page loads. */
        @Volatile var payload: String? = null
        var prepared = false
        /** The current page finished loading (same moment the claim screen fills). */
        var pageReady = false
        var fillStartedAt = 0L
        var reattached = false
        var loadedAt = 0L
        var photoCursor = 0
        /** Locked and unlocking within 30 s of the open: no load now, it loads at its unlock second. */
        var deferred = false
        /** First timed task of its unlock group: pre-warmed PREWARM_MS before the unlock. */
        var prewarm = false
        lateinit var chip: TextView
        val unlocked get() = unlockAt <= System.currentTimeMillis() + 300
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openCount++
        SessionStore.cancelScheduledClear()
        ManualRun.cancelNotification(this)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { getSystemService(KeyguardManager::class.java)?.requestDismissKeyguard(this, null) } catch (_: Exception) {}
        val app = applicationContext
        io.execute { try { ManualRun.markOpen(true) } catch (_: Exception) {} }

        try { SiteCookies.restore(this) } catch (_: Exception) {}
        try { EngagedLab.restore(this) } catch (_: Exception) {}
        try { SessionStore.injectIntoWebView(this) } catch (_: Exception) {}

        val db = DbStore.read()
        val qs = ManualRun.ids(db).mapNotNull { DbStore.quest(db, it) }
        buildUi()
        if (qs.isEmpty()) { toast("The manual run has no tasks."); finish(); return }
        qs.forEachIndexed { i, q -> tabs += Tab(q, i) }
        EventLog.add("manual", "manual run screen open: ${tabs.size} tab(s); the app's background Zealy requests wait until it closes")
        for (t in tabs) setupChip(t)
        planUnlocks()
        select(0)
        // Every WebView is built now, but only Tab 1 loads. Each other tab is queued and starts only after the
        // previous page finished loading (strictly one page at a time, see runOps()).
        setupWeb(tabs[0])
        enqueue(tabs[0], OpKind.LOAD, "first tab")
        main.post {
            for (t in tabs.drop(1)) setupWeb(t)
            for (t in tabs.drop(1)) if (!t.deferred) enqueue(t, OpKind.LOAD, "sequential")
        }
        tick()
    }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun left(secs: Long): String {
        val s = secs.coerceAtLeast(0)
        val h = s / 3600; val m = s % 3600 / 60; val ss = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, ss) else "%d:%02d".format(m, ss)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0b0b0f")) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#151519")); setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        prevBtn = Button(this).apply { text = "Prev"; isAllCaps = false; textSize = 13f; setOnClickListener { select(current - 1) } }
        nextBtn = Button(this).apply { text = "Next"; isAllCaps = false; textSize = 13f; setOnClickListener { select(current + 1) } }
        chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), 0, dp(4), 0) }
        chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }
        reloadBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_qp_reload); setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Reload this page"; setOnClickListener { reloadCurrent() }
        }
        val close = Button(this).apply { text = "Close"; isAllCaps = false; textSize = 13f; setOnClickListener { confirmClose() } }
        bar.elevation = dp(4).toFloat()
        bar.addView(prevBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        bar.addView(chipScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(nextBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        bar.addView(reloadBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
        stack = FrameLayout(this)
        banner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE
            setBackgroundColor(Color.parseColor("#3a1030")); setPadding(dp(12), dp(6), dp(4), dp(6))
        }
        bannerText = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f
            setOnClickListener { bannerLink?.let { l -> getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Post link", l)); toast("Link copied again.") } }
        }
        val bannerClose = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_menu_close_clear_cancel); setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { banner.visibility = View.GONE }
        }
        banner.addView(bannerText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        banner.addView(bannerClose, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(banner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        cfBanner = TextView(this).apply {
            setTextColor(Color.BLACK); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; visibility = View.GONE
            setBackgroundColor(Color.parseColor("#f5b942")); setPadding(dp(12), dp(8), dp(12), dp(8))
            text = "Human verification required – complete it in this window. Other tabs and claims are paused."
            setOnClickListener { challengeTab?.let { select(it.index) } }
        }
        col.addView(cfBanner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(stack, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        // Control bar (Prev | chips | Next | Close) at the bottom: thumb reach, the page gets the space above it.
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Claim result banner: floats over the top of the page on every tab. Not clickable, so taps go through to the
        // page below; it never covers the bottom bar.
        resultBanner = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(dp(14), dp(10), dp(14), dp(10)); maxLines = 2; visibility = View.GONE
            isClickable = false; isFocusable = false; elevation = dp(6).toFloat()
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#1d4d2c")) }
        }
        root.addView(resultBanner, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP).apply { setMargins(dp(10), dp(8), dp(10), 0) })
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, insets ->
            @Suppress("DEPRECATION")
            // bottom = navigation bar / gesture area: the bottom control bar sits above it
            v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            insets
        }
        links = LinkOverlay(this, root) { (sheetTab ?: tabs.getOrNull(current))?.web }
    }

    private fun chipLabel(t: Tab): String {
        val now = System.currentTimeMillis()
        val cool = cooldownUntil - now
        val state = when {
            challengeTab === t -> "human verification"
            t.claim == "waiting" && challengeTab != null -> "waiting · verification"
            t.claim == "waiting" && cool > 0 -> "waiting · Zealy limit ${(cool + 999) / 1000}s"
            t.claim.isNotEmpty() -> t.claim
            t.unlockAt > now -> (if (t.recurring) "resets in " else "unlocks in ") + left((t.unlockAt - now) / 1000)
            !t.loaded -> if (activeOp?.tab === t) "loading" else "waiting…"
            activeOp?.tab === t && !t.pageReady -> "loading"
            t.filled -> "filled"
            else -> "open"
        }
        return "${t.index + 1}. ${t.title.take(22)}${if (t.title.length > 22) "…" else ""} · $state"
    }

    private fun refreshChips() {
        for (t in tabs) {
            t.chip.text = chipLabel(t)
            val bg = t.chip.background as? GradientDrawable ?: continue
            val color = when (t.claim) {
                "claimed" -> "#1d4d2c"; "claiming" -> "#5a3a08"; "waiting" -> "#3a2f10"
                "failed", "no answer", "too many requests, tap Claim again" -> "#5a1717"; "in review" -> "#173a5a"
                else -> if (t.index == current) "#3a1030" else "#222228"
            }
            bg.setColor(Color.parseColor(color))
            bg.setStroke(dp(if (t.index == current) 2 else 0), Color.parseColor("#e05aae"))
        }
        prevBtn.isEnabled = current > 0
        nextBtn.isEnabled = current < tabs.size - 1
    }

    private fun tick() {
        if (closed) return
        refreshChips()
        // Waiting tabs show only the dark page area + spinner; their state ("waiting…", "unlocks in …") is on the chip.
        main.postDelayed({ tick() }, 1_000L)
    }

    private fun select(i: Int) {
        if (tabs.isEmpty()) return
        current = i.coerceIn(0, tabs.size - 1)
        // Switching only changes which page is visible: nothing is closed or reloaded.
        // The other tabs are moved off the screen, not hidden: a hidden WebView runs its page timers about once a
        // second, which made the autofill (it works in 150-300 ms steps) slow on every tab but the visible one.
        val off = offscreenX()
        for (t in tabs) { t.holder.visibility = View.VISIBLE; t.holder.translationX = if (t.index == current) 0f else off }
        tabs[current].holder.bringToFront()
        refreshChips()
        tabs[current].chip.let { c -> chipScroll.post { chipScroll.smoothScrollTo((c.left - dp(40)).coerceAtLeast(0), 0) } }
    }

    /** Far enough right that no tab peeks in, in either orientation. */
    private fun offscreenX(): Float = 3f * maxOf(resources.displayMetrics.widthPixels, resources.displayMetrics.heightPixels)

    private fun confirmClose() {
        val busy = inFlight != null || waiting.isNotEmpty()
        AlertDialog.Builder(this)
            .setTitle("Close the manual run?")
            .setMessage(if (busy) "A claim is still waiting or being sent. Closing stops it." else "All tabs close. The normal claim run resumes.")
            .setPositiveButton("Close") { _, _ -> finish() }
            .setNegativeButton("Stay", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (links.onBack()) return
        val w = tabs.getOrNull(current)?.web
        if (w != null && w.canGoBack()) { w.goBack(); return }
        confirmClose()
    }

    override fun showLinkBanner(link: String?, text: String) {
        bannerLink = link
        if (link != null) getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Post link", link))
        bannerText.text = text + if (link != null) " (tap to copy again)" else ""
        banner.visibility = View.VISIBLE
    }

    // ---------- tabs ----------
    private fun setupChip(t: Tab) {
        t.chip = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(10), dp(6), dp(10), dp(6)); maxLines = 1
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.parseColor("#222228")) }
            setOnClickListener { select(t.index) }
        }
        chipRow.addView(t.chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(3), 0, dp(3), 0) })
        t.placeholder.setBackgroundColor(Color.parseColor(PAGE_BG))
        t.placeholder.addView(ProgressBar(this, null, android.R.attr.progressBarStyleSmall).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#55555f"))
        }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        t.holder.setBackgroundColor(Color.parseColor(PAGE_BG))
        t.holder.addView(t.placeholder, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        stack.addView(t.holder, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        t.holder.translationX = offscreenX()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWeb(t: Tab) {
        if (closed || t.web != null) return
        val w = WebView(MutableContextWrapper(this))
        ZealyWeb.configure(w)
        w.settings.setSupportMultipleWindows(true)
        w.settings.javaScriptCanOpenWindowsAutomatically = true
        w.addJavascriptInterface(LinksBridge(t), "QPLinks")
        w.addJavascriptInterface(ZealyHookBridge(applicationContext), "QPZ")
        w.addJavascriptInterface(RunBridge(t), "QPRun")
        w.addJavascriptInterface(FillBridge(t), "QPBridge")
        val started = LinkOverlay.addStartScript(w, RUN_HOOK_JS, ZEALY_ORIGINS) and
            LinkOverlay.addStartScript(w, LinkOverlay.LINKS_JS, ZEALY_ORIGINS) and
            LinkOverlay.addStartScript(w, zHook, ZEALY_ORIGINS)
        w.webViewClient = client(t, started)
        w.webChromeClient = chrome(t)
        w.visibility = View.INVISIBLE
        w.setBackgroundColor(Color.parseColor(PAGE_BG)) // no white flash before Zealy paints
        t.holder.addView(w, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        t.web = w
        // Saved content is read and the photos encoded on the io thread while the page loads, so the fill can start
        // the moment the page is ready (before, the photos were encoded on the main thread at fill time, tab by tab).
        val ctx = applicationContext
        io.execute {
            val job = try { Autofill.prepare(ctx, t.questId, markUsed = false) } catch (_: Exception) { null }
            val payload = job?.takeIf { it.hasContent }?.let {
                try { Autofill.payload(it) } catch (_: Exception) { try { Autofill.payload(it, emptyList()) } catch (_: Exception) { null } }
            }
            try { fillJs; fillCfg } catch (_: Exception) {} // read the fill script once, off the main thread
            main.post {
                if (closed) return@post
                t.job = job
                t.payload = payload
                t.fillPending = job?.hasContent == true
                t.prepared = true
                if (t.pageReady) maybeFill(t) // the page was quicker than the preparation
            }
        }

        // A locked one gets its unlock work at its unlock second. It is only queued then: tabs unlocking in the
        // same second run one after the other (see runOps), never together.
        val now = System.currentTimeMillis()
        if (t.unlockAt > now) {
            main.postAtTime({ if (!closed) enqueue(t, OpKind.UNLOCK, "unlock second") }, SystemClock.uptimeMillis() + (t.unlockAt - now))
            // Auto reload: 3 s before the unlock. The setting is read when the moment comes, so switching it
            // while the run is open counts.
            val refreshIn = t.unlockAt - REFRESH_LEAD_MS - now
            if (refreshIn > 0) main.postAtTime({ if (!closed && !t.unlocked) refreshBeforeUnlock(t) }, SystemClock.uptimeMillis() + refreshIn)
            if (t.prewarm) {
                val at = (t.unlockAt - PREWARM_MS - now).coerceAtLeast(0L)
                main.postAtTime({ if (!closed && !t.loaded) enqueue(t, OpKind.LOAD, "pre-warm 10 s before unlock", urgent = true) }, SystemClock.uptimeMillis() + at)
            }
        }
    }

    /**
     * Decided once at open: which locked tabs wait for their unlock second (no load + reload), and which single
     * timed task per unlock group is pre-warmed 10 s ahead (never several at the same second).
     */
    private fun planUnlocks() {
        for (t in tabs) t.deferred = loadsAtUnlock(t)
        val timed = tabs.filter { it.deferred && !it.recurring }.sortedWith(compareBy({ it.unlockAt }, { it.index }))
        var groupStart = Long.MIN_VALUE
        for (t in timed) {
            if (t.unlockAt - groupStart > UNLOCK_GROUP_MS) { groupStart = t.unlockAt; t.prewarm = true }
        }
        val pw = tabs.filter { it.prewarm }
        if (pw.isNotEmpty()) EventLog.add("manual", "pre-warm planned for: " + pw.joinToString { "tab ${it.index + 1}" })
    }

    /** Locked and unlocking soon: it loads once, at its unlock second (a load now would be reloaded then anyway). */
    private fun loadsAtUnlock(t: Tab): Boolean {
        val left = t.unlockAt - System.currentTimeMillis()
        return t.index != 0 && left > 0 && left <= LOAD_AT_UNLOCK_WITHIN_MS
    }

    private fun startLoad(t: Tab) {
        if (closed || t.loaded) return
        val w = t.web ?: return
        t.loaded = true
        t.loadedAt = System.currentTimeMillis()
        t.loadedBeforeUnlock = !t.unlocked
        if (t.sub.isNotEmpty()) touchedSubs += t.sub
        w.visibility = View.VISIBLE
        // the dark placeholder + spinner stays on top until the page draws its first frame (onPageCommitVisible)
        w.loadUrl(t.url)
    }

    // ---------- page queue ----------
    /**
     * Queues page work for [t]. Unlock work and fill reloads go before plain sequential loads (they are time-critical),
     * after any unlock work already waiting; the same work for the same tab is never queued twice.
     */
    private fun enqueue(t: Tab, kind: OpKind, reason: String, urgent: Boolean = false) {
        if (closed) return
        if (ops.any { it.tab === t && it.kind == kind } || (activeOp?.let { it.tab === t && it.kind == kind } == true)) return
        if (kind == OpKind.LOAD && t.loaded) return
        if (kind != OpKind.LOAD) ops.removeAll { it.tab === t && it.kind == OpKind.LOAD } // the unlock work loads it
        val op = PageOp(t, kind, reason)
        if (kind == OpKind.LOAD && !urgent) ops.add(op)
        else {
            val pos = ops.indexOfFirst { it.kind == OpKind.LOAD }
            if (pos < 0) ops.add(op) else ops.add(pos, op)
        }
        runOps()
    }

    private fun runOps() {
        main.removeCallbacks(runOpsRunnable)
        if (closed || activeOp != null) return
        if (challengeTab != null) return // paused: human verification on screen
        val op = ops.removeFirstOrNull() ?: return
        activeOp = op
        val t = op.tab
        val to = Runnable {
            if (activeOp === op) {
                EventLog.add("manual", "tab ${t.index + 1} (${t.title}): page didn't finish in ${OP_TIMEOUT_MS / 1000} s, next tab goes on")
                finishOp(op, null)
            }
        }
        opTimeout = to
        main.postDelayed(to, OP_TIMEOUT_MS)
        when (op.kind) {
            OpKind.LOAD -> {
                if (t.loaded || t.web == null) { finishOp(op, null, gap = false); return }
                EventLog.add("manual", "tab ${t.index + 1} (${t.title}): " + when (op.reason) {
                    "first tab" -> "loading (first tab)"
                    "sequential" -> "starting after previous tab finished"
                    else -> "${op.reason}, starting after previous tab finished"
                })
                op.waitingForPage = true
                startLoad(t)
            }
            OpKind.RELOAD -> {
                val w = t.web ?: run { finishOp(op, null, gap = false); return }
                EventLog.add("manual", "tab ${t.index + 1} (${t.title}): ${op.reason}, starting after previous tab finished")
                op.waitingForPage = true
                if (w.url.isNullOrEmpty()) w.loadUrl(t.url) else w.reload()
            }
            OpKind.REFRESH -> {
                // Auto reload, 3 s before the unlock. Skipped when the unlock already passed while it waited in the
                // queue (the unlock work takes over) or when the setting was switched off meanwhile.
                val w = t.web
                if (w == null || !t.loaded || t.unlocked || !autoReload()) { finishOp(op, null, gap = false); return }
                EventLog.add("manual", "tab ${t.index + 1} (${t.title}): ${op.reason}, starting after previous tab finished")
                op.waitingForPage = true
                if (samePage(t, w.url)) w.reload() else w.loadUrl(t.url)
            }
            OpKind.UNLOCK -> doUnlock(op)
        }
        refreshChips()
    }

    /** Setting "Auto reload" (Settings > Manual run), on by default. Read from memory each time it matters. */
    private fun autoReload(): Boolean = try { DbStore.pref("manualAutoReload", true) } catch (_: Exception) { true }

    /**
     * Auto reload: REFRESH_LEAD_MS before the unlock the page is refreshed (loaded, when it wasn't loaded yet).
     * Goes through the page queue like every other page work: one page at a time.
     */
    private fun refreshBeforeUnlock(t: Tab) {
        if (closed || t.unlocked) return
        if (!autoReload()) {
            EventLog.add("manual", "tab ${t.index + 1} (${t.title}): auto reload is off, no refresh before the unlock")
            return
        }
        if (!t.loaded) enqueue(t, OpKind.LOAD, "auto reload: load 3 s before unlock", urgent = true)
        else enqueue(t, OpKind.REFRESH, "auto reload 3 s before unlock", urgent = true)
    }

    /** The reload icon in the bottom bar: reloads the page of the tab on screen (queued like any other page work). */
    private fun reloadCurrent() {
        val t = tabs.getOrNull(current) ?: return
        if (t.claim == "waiting" || t.claim == "claiming") {
            toast("A claim of this tab is waiting or being sent. Reload after it answers.")
            return
        }
        if (challengeTab === t) { t.web?.reload(); return } // the verification page itself: nothing is paused for it
        if (challengeTab != null) {
            toast("Finish the human verification on tab ${challengeTab!!.index + 1} first.")
            return
        }
        if (t.web == null) return
        // A reload empties the task box: fill it again (not on a page that was already claimed).
        if (t.claim == "" || t.claim == "failed" || t.claim == "no answer" || t.claim.startsWith("too many")) {
            t.claim = ""
            t.filled = false; t.fillRetries = 0; t.reattached = false
            t.fillPending = t.job?.hasContent == true
        }
        t.loadedAt = System.currentTimeMillis()
        if (!t.loaded) enqueue(t, OpKind.LOAD, "reload button", urgent = true)
        else enqueue(t, OpKind.RELOAD, "reload button", urgent = true)
        toast("Reloading tab ${t.index + 1}")
        refreshChips()
    }

    /** Ends [op] and lets the next queued page start CHAIN_GAP_MS later. */
    private fun finishOp(op: PageOp, log: String?, gap: Boolean = true) {
        if (activeOp !== op) return
        activeOp = null
        opTimeout?.let { main.removeCallbacks(it) }; opTimeout = null
        if (log != null) EventLog.add("manual", log)
        main.removeCallbacks(runOpsRunnable)
        if (gap) main.postDelayed(runOpsRunnable, CHAIN_GAP_MS) else main.post(runOpsRunnable)
        refreshChips()
    }

    /** The page of [t] finished loading: the page operation waiting for it is done. */
    private fun onTabFinished(t: Tab) {
        val op = activeOp ?: return
        if (op.tab === t && op.waitingForPage) finishOp(op, "tab ${t.index + 1} (${t.title}): page finished")
    }

    /** Unlock / reset second of [t]: soft update of the open page first, full reload only when that didn't work. */
    private fun doUnlock(op: PageOp) {
        val t = op.tab
        if (!t.loaded) {
            EventLog.add("manual", "tab ${t.index + 1} (${t.title}): unlock second, page loading")
            op.waitingForPage = true
            startLoad(t)
            return
        }
        if (!t.loadedBeforeUnlock) { finishOp(op, null, gap = false); return } // its page was opened after the unlock already
        t.loadedBeforeUnlock = false
        t.filled = false; t.fillRetries = 0; t.reattached = false
        t.fillPending = t.job?.hasContent == true
        val w = t.web ?: run { finishOp(op, null, gap = false); return }
        if (!samePage(t, w.url)) {
            // You moved to another Zealy page in this tab: the quest itself is loaded again.
            if (!autoReload()) {
                EventLog.add("manual", "tab ${t.index + 1} (${t.title}): unlock second, tab shows another page, auto reload is off")
                finishOp(op, null, gap = false)
                return
            }
            EventLog.add("manual", "tab ${t.index + 1} (${t.title}): unlock second, tab shows another page: quest page loaded")
            dropQueued(t)
            op.waitingForPage = true
            w.loadUrl(t.url)
            return
        }
        // Soft update: the page stays, Zealy is told it was shown again (nothing is clicked), plus one native check.
        EventLog.add("manual", "tab ${t.index + 1} (${t.title}): unlock second, soft update tried")
        op.softStartedAt = SystemClock.uptimeMillis()
        w.evaluateJavascript(SoftUpdate.SOFT_JS, null)
        UnlockStatus.check(applicationContext, t.q, manual = true) { st ->
            if (closed) return@check
            op.native = st
            EventLog.add("manual", "tab ${t.index + 1} (${t.title}): native status check: $st")
        }
        softPoll(op, if (t.recurring) SOFT_WAIT_RECURRING_MS else SOFT_WAIT_TIMED_MS)
    }

    private fun softPoll(op: PageOp, limit: Long) {
        val t = op.tab
        main.postDelayed({
            if (closed || activeOp !== op || op.waitingForPage) return@postDelayed
            val w = t.web ?: run { finishOp(op, null); return@postDelayed }
            w.evaluateJavascript(SoftUpdate.PROBE_JS) { res ->
                if (closed || activeOp !== op || op.waitingForPage) return@evaluateJavascript
                val p = SoftUpdate.parse(res)
                val el = SystemClock.uptimeMillis() - op.softStartedAt
                when {
                    p.claim -> {
                        EventLog.add("manual", "tab ${t.index + 1} (${t.title}): soft update worked, Claim button there after $el ms")
                        t.loadedAt = System.currentTimeMillis()
                        if (t.pageReady) maybeFill(t)
                        finishOp(op, null)
                    }
                    el < limit -> softPoll(op, limit)
                    op.native == UnlockStatus.LOCKED && !op.extended -> {
                        // Zealy itself still says locked (clock a little early): one more soft try before the reload.
                        op.extended = true
                        EventLog.add("manual", "tab ${t.index + 1} (${t.title}): Zealy still says locked, soft update tried again")
                        w.evaluateJavascript(SoftUpdate.SOFT_JS, null)
                        softPoll(op, limit + SOFT_EXTEND_MS)
                    }
                    !autoReload() -> {
                        EventLog.add("manual", "tab ${t.index + 1} (${t.title}): soft update failed, auto reload is off: reload with the button")
                        finishOp(op, null)
                    }
                    else -> {
                        EventLog.add("manual", "tab ${t.index + 1} (${t.title}): soft update failed, full reload")
                        dropQueued(t)
                        op.waitingForPage = true
                        w.reload()
                    }
                }
            }
        }, SOFT_POLL_MS)
    }

    /** The tab still shows its own quest (not the questboard or another quest). */
    private fun samePage(t: Tab, current: String?): Boolean {
        if (current.isNullOrEmpty()) return false
        val zid = t.q.optString("zealyId").takeIf { it.isNotEmpty() && !t.q.isNull("zealyId") }
        if (zid != null) return current.contains(zid, ignoreCase = true)
        fun norm(u: String) = u.substringBefore('#').substringBefore('?').trimEnd('/').lowercase()
        return norm(current) == norm(t.url)
    }

    // ---------- human verification (Cloudflare) ----------
    private fun onChallenge(t: Tab, where: String) {
        if (closed) return
        if (challengeTab === t) return
        if (challengeTab == null) {
            challengeTab = t
            CfChallenge.shown(challengeKey, "manual run tab ${t.index + 1}, $where")
            EventLog.add("manual", "tab ${t.index + 1} (${t.title}): human verification page ($where): page queue and claim queue paused")
            main.removeCallbacks(pumpRunnable)
            main.removeCallbacks(runOpsRunnable)
            activeOp?.let { if (it.tab === t) finishOp(it, null, gap = false) }
            main.removeCallbacks(runOpsRunnable) // finishOp re-posts it: stay paused
            select(t.index)
            cfBanner.visibility = View.VISIBLE
            toast("Human verification required – complete it in this window.")
            pollChallenge(t)
        }
        refreshChips()
    }

    /** Backup for the page-finished check: two clean reads in a row (the solve redirect has settled) end the pause. */
    private fun pollChallenge(t: Tab, clean: Int = 0) {
        main.postDelayed({
            if (closed || challengeTab !== t) return@postDelayed
            val w = t.web ?: run { onChallengeCleared(t); return@postDelayed }
            w.evaluateJavascript(CfChallenge.DETECT_JS) { res ->
                if (closed || challengeTab !== t) return@evaluateJavascript
                val ok = !CfChallenge.parse(res) && ZealyWeb.isZealy(Uri.parse(w.url ?: "")) && !CfChallenge.isChallengeUrl(w.url) && t.pageReady
                if (ok && clean >= 1) onChallengeCleared(t) else pollChallenge(t, if (ok) clean + 1 else 0)
            }
        }, CHALLENGE_POLL_MS)
    }

    private fun onChallengeCleared(t: Tab) {
        if (challengeTab !== t) return
        challengeTab = null
        CfChallenge.cleared(challengeKey, "manual run tab ${t.index + 1}")
        cfBanner.visibility = View.GONE
        EventLog.add("manual", "tab ${t.index + 1} (${t.title}): human verification done, page queue and claim queue resume")
        refreshChips()
        main.postDelayed(runOpsRunnable, CHAIN_GAP_MS)
        pump()
    }

    /** Reads the finished main frame for challenge markers; clears the pause when this tab's challenge is gone. */
    private fun checkChallenge(t: Tab, view: WebView, then: () -> Unit) {
        view.evaluateJavascript(CfChallenge.DETECT_JS) { res ->
            if (closed) return@evaluateJavascript
            if (CfChallenge.parse(res)) onChallenge(t, "page content")
            else if (challengeTab === t && !CfChallenge.isChallengeUrl(view.url)) onChallengeCleared(t)
            then()
        }
    }

    private fun client(t: Tab, startScripts: Boolean) = object : WebViewClient() {
        override fun onPageCommitVisible(view: WebView, url: String) {
            t.placeholder.visibility = View.GONE // first frame drawn: the real page replaces the dark placeholder
            // The fill starts as soon as the page draws (not at the full "loaded" event, which waits for every image
            // and script); the fill script itself waits until React has wired the task box.
            t.pageReady = ZealyWeb.isZealy(Uri.parse(url))
            if (t.unlocked && t.pageReady) maybeFill(t)
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
            // Zealy changed the address inside the page (e.g. questboard -> the quest): fill once it is the quest.
            if (t.fillPending && t.pageReady && t.unlocked) main.post { maybeFill(t) }
        }

        override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
            val u = req.url
            if (ZealyWeb.isZealy(u) || u.scheme == "about" || u.scheme == "blob" || u.scheme == "data") return false
            // Cloudflare / captcha frames and /cdn-cgi/ always load untouched.
            if (!req.isForMainFrame && CfChallenge.isChallengeResource(u)) return false
            if (req.isForMainFrame || req.hasGesture()) { if (t.index != current) select(t.index); sheetTab = t; links.open(u.toString(), null) }
            return true
        }

        override fun onReceivedHttpError(view: WebView, req: WebResourceRequest, resp: android.webkit.WebResourceResponse) {
            if (req.isForMainFrame && CfChallenge.isMitigated(resp)) main.post { onChallenge(t, "cf-mitigated ${resp.statusCode}") }
        }

        override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
            if (CfChallenge.isChallengeUrl(url)) main.post { onChallenge(t, "challenge URL") }
            dropQueued(t) // a held request of the old page is gone with it
            t.pageReady = false
            if (startScripts) return
            view.evaluateJavascript(RUN_HOOK_JS, null)
            view.evaluateJavascript(LinkOverlay.LINKS_JS, null)
            view.evaluateJavascript(zHook, null)
        }

        override fun onPageFinished(view: WebView, url: String) {
            t.placeholder.visibility = View.GONE
            if (!startScripts) {
                view.evaluateJavascript(RUN_HOOK_JS, null)
                view.evaluateJavascript(LinkOverlay.LINKS_JS, null)
                view.evaluateJavascript(zHook, null)
            }
            val app = applicationContext
            try { io.execute { try { android.webkit.CookieManager.getInstance().flush(); EngagedLab.saveFromJar(app) } catch (_: Exception) {} } } catch (_: Exception) {}
            t.pageReady = ZealyWeb.isZealy(Uri.parse(url))
            if (t.unlocked && t.pageReady) maybeFill(t)
            // Challenge check first, then (sequential loading) this page is done and the next queued tab may start:
            // a verification page found here pauses the queue before anything else starts.
            checkChallenge(t, view) { onTabFinished(t) }
        }
    }

    private fun chrome(t: Tab) = object : WebChromeClient() {
        override fun onReceivedTitle(view: WebView, title: String?) {
            if (CfChallenge.isChallengeTitle(title)) main.post { onChallenge(t, "page title") }
        }

        override fun onShowFileChooser(view: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
            // A saved photo of this task is offered first, like on the claim screen; else the system picker.
            fileCallback?.onReceiveValue(null)
            val photos = t.job?.photos.orEmpty()
            if (photos.isNotEmpty()) {
                val f = photos[t.photoCursor % photos.size]; t.photoCursor++
                val uri = try { SavedPhotos.uri(this@ManualRunActivity, f) } catch (_: Exception) { null }
                if (uri != null) { cb.onReceiveValue(arrayOf(uri)); return true }
            }
            fileCallback = cb
            return try { startActivityForResult(params.createIntent(), 4711); true } catch (_: Exception) { fileCallback = null; false }
        }

        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message): Boolean {
            val tmp = WebView(this@ManualRunActivity)
            var handled = false
            tmp.webViewClient = object : WebViewClient() {
                fun take(u: String?) {
                    if (handled || u.isNullOrEmpty() || u == "about:blank") return
                    handled = true
                    if (ZealyWeb.isZealy(Uri.parse(u))) t.web?.loadUrl(u) else { if (t.index != current) select(t.index); sheetTab = t; links.open(u, null) }
                    main.post { tmp.destroy() }
                }
                override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean { take(req.url.toString()); return true }
                override fun onPageStarted(v: WebView, url: String, favicon: android.graphics.Bitmap?) { take(url) }
            }
            val transport = resultMsg.obj as? WebView.WebViewTransport ?: return false
            transport.webView = tmp
            resultMsg.sendToTarget()
            main.postDelayed({ if (!handled) tmp.destroy() }, 10_000)
            return true
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 4711) return
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
        fileCallback = null
    }

    // ---------- autofill (saved content), same script and selectors as the claim screen ----------
    private fun maybeFill(t: Tab) {
        if (!t.prepared) return // called again when the saved content is ready
        val job = t.job ?: return
        if (!t.fillPending || closed || !t.unlocked) return
        val w = t.web ?: return
        if (!Autofill.matches(job, w.url)) return // another page: never fill
        val js = fillJs ?: return
        t.fillPending = false
        val payload = t.payload ?: try { Autofill.payload(job) } catch (_: Exception) { Autofill.payload(job, emptyList()) }
        t.fillStartedAt = System.currentTimeMillis()
        w.evaluateJavascript(js, null)
        w.evaluateJavascript("window.__qpFill($fillCfg, $payload)", null)
    }

    /** Result from qp-fill.js (same format as on the claim screen). */
    private fun onFillReport(t: Tab, json: String) {
        val j = t.job ?: return
        if (!Autofill.matches(j, t.web?.url)) return
        val r = try { JSONObject(json) } catch (_: Exception) { return }
        if (r.optBoolean("blocked")) return
        val textMissing = r.optString("text") == "missing"
        val photoMissing = r.optString("photo") == "missing"
        val photoUnsure = r.optString("photo") == "unconfirmed"
        val secs = if (t.fillStartedAt > 0) String.format("%.1f", (System.currentTimeMillis() - maxOf(t.loadedAt, t.unlockAt)) / 1000.0) else "?"
        EventLog.add("manual", "${t.title}: autofill text ${r.optString("text")}, photo ${r.optString("photo")}${if (r.optBoolean("manual")) " (2nd try)" else ""} · ${secs} s after the page opened")
        if (r.optBoolean("manual")) {
            if (!photoMissing && !photoUnsure && t.index == current) toast("Saved photo attached. Check it, then tap Claim yourself.")
            refreshChips()
            return
        }
        if (photoUnsure && !t.reattached && !textMissing) {
            // The file was set but the page showed no upload yet: try the photo once more a moment later.
            t.reattached = true
            t.filled = true
            main.postDelayed({
                val w = t.web ?: return@postDelayed
                val js = fillJs ?: return@postDelayed
                if (closed || !Autofill.matches(j, w.url)) return@postDelayed
                w.evaluateJavascript(js, null)
                w.evaluateJavascript("window.__qpAttach($fillCfg, ${t.payload ?: Autofill.payload(j)})", null)
            }, 1_500L)
            io.execute { try { Autofill.commitUsed(j) } catch (_: Exception) {} }
            refreshChips()
            return
        }
        if (!textMissing && !photoMissing) {
            t.filled = true
            io.execute { try { Autofill.commitUsed(j) } catch (_: Exception) {} }
            if (t.index == current) toast(if (photoUnsure) "Filled in (photo not confirmed). Check it, then tap Claim yourself." else "Filled in. Check it, then tap Claim yourself.")
        } else if (t.fillRetries < FILL_MAX_RETRIES && t.claim.isEmpty() &&
            System.currentTimeMillis() - maxOf(t.loadedAt, t.unlockAt) in 0..FILL_RETRY_WINDOW_MS) {
            // Same as the claim screen: the page wasn't ready (or Zealy still served the locked page right after
            // the unlock): reload this tab and fill again. Never while a claim of this tab is waiting or sent.
            t.fillRetries++
            t.fillPending = true
            EventLog.add("manual", "${t.title}: task box not on the page yet, reload ${t.fillRetries} queued")
            enqueue(t, OpKind.RELOAD, "fill reload ${t.fillRetries}")
        } else if (t.index == current) {
            toast("Couldn't autofill this task. Its saved content is in the app.")
        }
        refreshChips()
    }

    inner class FillBridge(private val t: Tab) {
        @JavascriptInterface fun report(json: String) { main.post { onFillReport(t, json) } }
        @JavascriptInterface fun step(msg: String) { /* the claim screen shows these in its debug line; not needed here */ }
        @JavascriptInterface fun log(msg: String) {}
    }

    inner class LinksBridge(private val t: Tab) {
        @JavascriptInterface fun open(url: String, card: String) = main.post { if (t.index == current) { sheetTab = t; links.open(url, card) } }
        @JavascriptInterface fun visible(json: String) = main.post {
            if (t.index != current) return@post
            val arr = try { org.json.JSONArray(json) } catch (_: Exception) { return@post }
            links.preloadVisible((0 until arr.length()).map { arr.optString(it) })
        }
    }

    // ---------- claim queue ----------
    inner class RunBridge(private val t: Tab) {
        @JavascriptInterface fun request(id: String, url: String) { main.post { onRequest(t, id) } }
        @JavascriptInterface fun done(id: String, status: Int, body: String) { main.post { onDone(t, id, status, body) } }
    }

    private fun onRequest(t: Tab, id: String) {
        if (closed) return
        // Stacked = another claim is still waiting or in flight. A tap on an idle queue goes out at once.
        val stacked = inFlight != null || waiting.isNotEmpty()
        waiting.addLast(Req(t, id, stacked))
        t.claim = "waiting"
        EventLog.add("manual", "${t.title}: claim tapped, queued (${waiting.size + (if (inFlight != null) 1 else 0)} in queue)")
        // Your tap: a "use once" saved entry counts as used now, like on the claim screen.
        t.job?.let { j -> io.execute { try { Autofill.commitUsed(j) } catch (_: Exception) {} } }
        refreshChips()
        pump()
    }

    private fun pump() {
        main.removeCallbacks(pumpRunnable)
        if (closed || inFlight != null) return
        if (challengeTab != null) return // paused until the human verification is done (resumed by onChallengeCleared)
        val r = waiting.firstOrNull() ?: return
        // Idle queue (you waited for the previous answer, then tapped): no artificial gap. Stacked claims go out
        // STACKED_GAP_MS after the previous answer. The 429 cooldown always applies.
        val gapUntil = if (r.stacked && lastDoneAt > 0) lastDoneAt + STACKED_GAP_MS else 0L
        val wait = maxOf(gapUntil, cooldownUntil) - System.currentTimeMillis()
        if (wait > 0) { main.postDelayed(pumpRunnable, wait); return }
        waiting.removeFirst()
        inFlight = r
        r.tab.claim = "claiming"
        refreshChips()
        val to = Runnable {
            if (inFlight === r) {
                EventLog.add("manual", "${r.tab.title}: claim had no answer in 30 s, queue freed")
                r.tab.claim = "no answer"
                showResult("No answer: ${r.tab.title}", "#5a1717")
                inFlight = null
                lastDoneAt = System.currentTimeMillis()
                refreshChips()
                pump()
            }
        }
        timeoutRunnable = to
        main.postDelayed(to, CLAIM_TIMEOUT_MS)
        val w = r.tab.web
        if (w == null) { finishReq(r, 0, ""); return }
        w.evaluateJavascript("window.__qpRunGo?window.__qpRunGo(${JSONObject.quote(r.id)}):false") { res ->
            if (res != "true" && inFlight === r) {
                // The page that held it was reloaded or left: nothing to send, next one.
                r.tab.claim = ""
                inFlight = null
                timeoutRunnable?.let { main.removeCallbacks(it) }
                refreshChips()
                pump()
            }
        }
    }

    private fun onDone(t: Tab, id: String, status: Int, body: String) {
        val r = inFlight
        if (r != null && r.tab === t && r.id == id) finishReq(r, status, body)
        else { // late answer after the 30 s timeout
            t.claim = claimState(status, body); refreshChips()
            when (t.claim) {
                "claimed" -> showResult("Claimed: ${t.title}", "#1d6b37")
                "in review" -> showResult("In review: ${t.title}", "#1d4f7a")
                else -> showResult("Failed: ${t.title}", "#8a1f1f")
            }
        }
    }

    private fun finishReq(r: Req, status: Int, body: String) {
        timeoutRunnable?.let { main.removeCallbacks(it) }
        timeoutRunnable = null
        inFlight = null
        lastDoneAt = System.currentTimeMillis()
        r.tab.claim = claimState(status, body)
        if (status == 429) {
            // Too many requests: Zealy didn't take this claim. Nothing is re-sent for you; the next claim waits
            // 35 s (50 s for another 429 within 60 s) so it doesn't get the same answer.
            val now = System.currentTimeMillis()
            val cd = if (last429At > 0 && now - last429At < 60_000L) COOLDOWN_REPEAT_MS else COOLDOWN_MS
            last429At = now
            cooldownUntil = now + cd
            r.tab.claim = "too many requests, tap Claim again"
            EventLog.add("manual", "${r.tab.title}: Zealy said too many requests (429); next claim waits ${cd / 1000} s")
            showResult("Too many requests — wait ${cd / 1000} s before next claim (${r.tab.title.take(24)})", "#7a4a08", cd.coerceAtMost(6_000L))
        } else {
            EventLog.add("manual", "${r.tab.title}: claim answered $status (${r.tab.claim})")
            when (r.tab.claim) {
                "claimed" -> showResult("Claimed: ${r.tab.title}", "#1d6b37")
                "in review" -> showResult("In review: ${r.tab.title}", "#1d4f7a")
                else -> showResult("Failed: ${r.tab.title}", "#8a1f1f")
            }
        }
        refreshChips()
        pump() // a stacked claim goes out STACKED_GAP_MS after this answer; the next tap on an idle queue at once
    }

    /**
     * Claim result at the top of the screen, on whichever tab is showing, the moment the answer arrives.
     * Replaces the previous one; hides after RESULT_BANNER_MS. Never takes taps.
     */
    private fun showResult(text: String, color: String, ms: Long = RESULT_BANNER_MS) {
        if (closed || !::resultBanner.isInitialized) return
        main.removeCallbacks(hideResult)
        resultBanner.animate().cancel()
        resultBanner.text = text
        (resultBanner.background as? GradientDrawable)?.setColor(Color.parseColor(color))
        resultBanner.alpha = 1f
        resultBanner.visibility = View.VISIBLE
        resultBanner.bringToFront() // above the page and an open link sheet
        main.postDelayed(hideResult, ms)
    }

    /** 2xx = claimed, unless the answer says it failed or waits for review. */
    private fun claimState(status: Int, body: String): String {
        if (status !in 200..299) return "failed"
        val s = try { JSONObject(body).optString("status").lowercase() } catch (_: Exception) { "" }
        return when {
            "fail" in s || "reject" in s -> "failed"
            "pending" in s || "review" in s -> "in review"
            else -> "claimed"
        }
    }

    private fun dropQueued(t: Tab) {
        val had = waiting.removeAll { it.tab === t }
        if (had && t.claim == "waiting") t.claim = ""
        if (had) refreshChips()
    }

    // ---------- close ----------
    override fun onDestroy() {
        closed = true
        main.removeCallbacksAndMessages(null)
        if (challengeTab != null) { challengeTab = null; CfChallenge.cleared(challengeKey, "manual run closed") }
        try { links.destroy() } catch (_: Exception) {}
        try { android.webkit.CookieManager.getInstance().flush() } catch (_: Exception) {}
        try { SessionStore.captureFromWebView(this) } catch (_: Exception) {}
        try { EngagedLab.saveFromJar(this) } catch (_: Exception) {}
        for (t in tabs) t.web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        tabs.clear()
        fileCallback?.onReceiveValue(null); fileCallback = null
        super.onDestroy()
        openCount--
        if (openCount <= 0 && ClaimActivity.openCount <= 0) SessionStore.scheduleClear()
        val app = applicationContext
        val subs = touchedSubs.toList()
        // The manual run is over: the normal claim run may open again; then the touched communities re-sync, as
        // after a claim page. On the same thread as markOpen(true), so the order of the two writes is kept.
        try {
            io.execute {
                try { ManualRun.markOpen(false); EventLog.add("manual", "manual run closed") } catch (_: Exception) {}
                if (subs.isNotEmpty() && SessionStore.hasSession(app)) {
                    try { Thread.sleep(500) } catch (_: Exception) {}
                    for (s in subs) try { ZealyGate.priority { ZealySync.syncAll(app, s) } } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
        io.shutdown()
    }
}
