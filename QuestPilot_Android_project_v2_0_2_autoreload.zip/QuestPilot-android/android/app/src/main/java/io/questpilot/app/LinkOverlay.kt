package io.questpilot.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject

/**
 * Part D: every non-Zealy link opens inside the app.
 *
 *   OTHER   : full-screen overlay WebView, small back arrow top-left closes it (D1)
 *   LIKE / REPOST : same overlay, auto-closes N seconds after the page loaded (D2, N = Debug slider).
 *            v2.4.7: N = 0 loads the page hidden (1 px, almost transparent, behind the Zealy page, not
 *            touchable): nothing is shown, then the very same close path runs (same events, same order).
 *   POST (reply, tweet, quote): X in a bottom sheet over 65% of the screen; when the post succeeds the
 *            link is copied, the sheet closes and the link is pasted into the task card you tapped (D3)
 *   FOLLOW  : full-screen overlay like LIKE / REPOST (v2.4.1, so the Zealy page behind it updates
 *            normally); closes as soon as the follow succeeds or you already follow (D4). No timer.
 *
 * QuestPilot never taps anything on X: every like, repost, post and follow tap is yours.
 * Each feature has its own Debug switch (prefs); with a switch off the link falls back to the plain overlay.
 */
/** v2.0.2: a screen that can show the "link copied, paste it yourself" banner (ClaimActivity, ManualRunActivity). */
interface LinkBannerHost {
    fun showLinkBanner(link: String?, text: String)
}

@SuppressLint("SetJavaScriptEnabled")
class LinkOverlay(private val act: Activity, private val root: FrameLayout, private val zealy: () -> WebView?) {
    enum class Kind { OTHER, LIKE, REPOST, POST, FOLLOW }

    companion object {
        /** v2.4.7 Fix 2: hidden load (slider 0 s): the stand-in window stays open at least / at most this long. */
        private const val HIDDEN_MIN_MS = 1_600L
        private const val HIDDEN_MAX_MS = 4_000L
        /** v2.4.7 Fix 6c: one background thread for cookie snapshots (keeps them in order). */
        private val snapshotExec = java.util.concurrent.Executors.newSingleThreadExecutor()
        private val X_HOSTS = setOf("x.com", "twitter.com", "mobile.x.com", "mobile.twitter.com", "www.x.com", "www.twitter.com")
        private val X_RESERVED = setOf(
            "home", "explore", "i", "search", "notifications", "messages", "settings", "intent", "compose", "share", "login", "logout",
            "signup", "hashtag", "tos", "privacy", "account", "download", "jobs", "lists", "bookmarks", "communities", "premium", "verified-choose",
        )

        fun isX(u: Uri?) = u?.host?.lowercase() in X_HOSTS

        fun classify(url: String): Kind {
            val u = try { Uri.parse(url) } catch (_: Exception) { return Kind.OTHER }
            if (!isX(u)) return Kind.OTHER
            val segs = u.pathSegments.map { it.lowercase() }
            val p = "/" + segs.joinToString("/")
            return when {
                p.startsWith("/intent/like") || p.startsWith("/intent/favorite") -> Kind.LIKE
                p.startsWith("/intent/retweet") -> Kind.REPOST
                p.startsWith("/intent/tweet") || p.startsWith("/intent/post") || p.startsWith("/compose/tweet") || p.startsWith("/compose/post") || p == "/share" -> Kind.POST
                p.startsWith("/intent/follow") || p.startsWith("/intent/user") -> Kind.FOLLOW
                segs.size == 1 && segs[0] !in X_RESERVED && Regex("^[a-z0-9_]{1,15}$").matches(segs[0]) -> Kind.FOLLOW
                else -> Kind.OTHER
            }
        }

        /** Hooks X's own network calls in the X page. Reports only paths and status codes, never cookies or tokens. */
        val X_HOOK_JS = """
(function(){if(window.__qpx)return;window.__qpx=1;
function rep(m,a,b){try{QPX[m](String(a||''),String(b||''));}catch(e){}}
function path(u){try{return new URL(u,location.href).pathname;}catch(e){return String(u).split('?')[0];}}
function handleOf(){try{var a=document.querySelector('[data-testid="AppTabBar_Profile_Link"]');if(a){var m=a.getAttribute('href').match(/^\/([A-Za-z0-9_]{1,15})/);if(m)return m[1];}}catch(e){}return '';}
function parsePost(t){try{var j=typeof t==='string'?JSON.parse(t):t;var d=j&&j.data||{};var c=d.create_tweet||d.notetweet_create||d.create_note_tweet||{};var r=(c.tweet_results||{}).result||{};if(r.tweet)r=r.tweet;
var id=r.rest_id||(r.legacy&&r.legacy.id_str);var h='';try{var us=r.core.user_results.result;h=(us.core&&us.core.screen_name)||(us.legacy&&us.legacy.screen_name)||'';}catch(e){}
if(id)rep('posted',id,h||handleOf());else rep('postFailed',(j&&j.errors?JSON.stringify(j.errors).slice(0,160):'no post id'),'');}catch(e){rep('postFailed','unreadable response','');}}
function seen(u,st,body){var p=path(u);if(/\/i\/api\/|\/1\.1\/|\/2\/|graphql/.test(p))rep('req',p,st);
var ok=st>=200&&st<300;
if(/CreateTweet|CreateNoteTweet/.test(p)){if(ok)parsePost(body);else rep('postFailed','HTTP '+st,'');}
if(/friendships\/create/.test(p)&&ok)rep('followed','api','');
if(/CreateRetweet|FavoriteTweet/.test(p)&&ok)rep('engaged',p,'');}
var of=window.fetch;if(of)window.fetch=function(i,n){var u=(typeof i==='string')?i:(i&&i.url)||'';return of.apply(this,arguments).then(function(r){try{if(/CreateTweet|CreateNoteTweet/.test(u))r.clone().text().then(function(t){seen(u,r.status,t);});else seen(u,r.status,'');}catch(e){}return r;});};
var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;
XMLHttpRequest.prototype.open=function(m,u){this.__qpu=u;return xo.apply(this,arguments);};
XMLHttpRequest.prototype.send=function(){var x=this;x.addEventListener('load',function(){var b='';try{if(/CreateTweet|CreateNoteTweet/.test(x.__qpu)){b=(x.responseType===''||x.responseType==='text')?x.responseText:(x.responseType==='json'?x.response:'');}}catch(e){}seen(x.__qpu,x.status,b);});return xs.apply(this,arguments);};
var last='';function scan(){try{var t=document.querySelector('[data-testid="toast"]');if(t){var tx=(t.innerText||'');if(/sent|posted|reply|replied/i.test(tx)){var a=t.querySelector('a[href*="/status/"]');var k='toast'+(a?a.href:'')+tx;if(k!==last){last=k;rep('toast',a?a.href:'',tx.slice(0,80));}}}
var uf=document.querySelector('[data-testid$="-unfollow"]');if(uf){if(last!=='following'){last='following';rep('following','button','');}return;}
var b=[].slice.call(document.querySelectorAll('[role=button],button')).find(function(x){return /^\s*Following\s*$/i.test(x.innerText||'');});if(b&&last!=='following'){last='following';rep('following','text','');}}catch(e){}}
function start(){try{new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true,characterData:true});}catch(e){}scan();}
if(document.documentElement)start();else document.addEventListener('DOMContentLoaded',start);
})();
""".trimIndent()

        /**
         * Zealy page: reports every window.open / outside link with the task card you tapped. Cards get a
         * data-qp-card id so the post link can later be pasted into the same card. Zealy's own click
         * handlers still run (no stopPropagation), and window.open returns a stand-in window that turns
         * `closed` and fires focus when the overlay closes, so Zealy notices you came back.
         */
        val LINKS_JS = """
(function(){if(window.__qpLinks)return;window.__qpLinks=1;
var seq=0,lastCard='',lastAt=0,wins=[];
var IN='input[type=url],input[type=text],input:not([type]),textarea,[contenteditable=true]';
function cardOf(el){var n=el;for(var i=0;i<14&&n&&n!==document.body;i++){try{if(n.querySelector&&n.querySelector(IN)&&n.offsetHeight<1400)return n;}catch(e){}n=n.parentElement;}
n=el;for(var j=0;j<5&&n&&n.parentElement;j++)n=n.parentElement;return n;}
function idOf(el){var c=cardOf(el);if(!c||!c.dataset)return '';if(!c.dataset.qpCard)c.dataset.qpCard='c'+(++seq);return c.dataset.qpCard;}
function outside(h){try{var u=new URL(h,location.href);if(!/^https?:$/.test(u.protocol))return false;return !/(^|\.)zealy\.io$/i.test(u.hostname);}catch(e){return false;}}
document.addEventListener('click',function(e){try{lastCard=idOf(e.target);lastAt=Date.now();var a=e.target.closest&&e.target.closest('a[href]');
if(a&&outside(a.href)){QPLinks.open(a.href,lastCard);e.preventDefault();}}catch(x){}},true);
var wo=window.open;window.open=function(u){try{var abs=new URL(u||'',location.href).href;if(outside(abs)){var card=(Date.now()-lastAt<3000)?lastCard:'';QPLinks.open(abs,card);
var w={closed:false,opener:window,focus:function(){},blur:function(){},close:function(){w.closed=true;},postMessage:function(){},location:{href:abs,replace:function(){},assign:function(){}},document:{write:function(){},close:function(){}}};wins.push(w);return w;}}catch(x){}
return wo.apply(window,arguments);};
window.__qpOverlayOpened=function(){window.__qpAwayAt=Date.now();try{window.dispatchEvent(new Event('blur'));}catch(e){}
clearTimeout(window.__qpBackT);window.__qpBackT=setTimeout(function(){try{window.dispatchEvent(new Event('focus'));}catch(e){}},1600);};
window.__qpOverlayClosed=function(){wins.forEach(function(w){w.closed=true;});wins=[];var away=Date.now()-(window.__qpAwayAt||0);window.__qpAwayAt=0;
setTimeout(function(){try{window.dispatchEvent(new Event('focus'));document.dispatchEvent(new Event('visibilitychange'));}catch(e){}},away<1600?1600-away:0);};
window.__qpScanIntents=function(){try{var out=[];document.querySelectorAll('a[href*="intent/like"],a[href*="intent/retweet"],a[href*="intent/favorite"]').forEach(function(a){var r=a.getBoundingClientRect();if(r.width>0&&r.bottom>0&&r.top<innerHeight)out.push(a.href);});QPLinks.visible(JSON.stringify(out.slice(0,3)));}catch(e){}};
window.__qpPaste=function(card,link){function vis(e){return e&&e.getClientRects().length>0;}
var sels='input[type=url],input[type=text],input:not([type]),textarea';var el=null;
if(card){var r=document.querySelector('[data-qp-card="'+card+'"]');if(r)el=[].slice.call(r.querySelectorAll(sels)).find(function(x){return vis(x)&&!x.disabled&&!x.readOnly;});}
if(!el)el=[].slice.call(document.querySelectorAll('input[type=url]')).find(function(x){return vis(x)&&!x.value;});
if(!el)el=[].slice.call(document.querySelectorAll(sels)).find(function(x){return vis(x)&&!x.value&&/http|link|url|tweet|post/i.test((x.placeholder||'')+(x.name||'')+(x.getAttribute('aria-label')||''));});
if(!el)return 'none';el.focus();var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
Object.getOwnPropertyDescriptor(proto,'value').set.call(el,link);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
setTimeout(function(){el.dispatchEvent(new Event('blur',{bubbles:true}));},0);return (el.value===link)?'ok':'unconfirmed';};
})();
""".trimIndent()

        /** Installs [js] at document start when the WebView supports it (falls back to onPageStarted/Finished injection). */
        fun addStartScript(w: WebView, js: String, origins: Set<String>): Boolean = try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) { WebViewCompat.addDocumentStartJavaScript(w, js, origins); true } else false
        } catch (_: Exception) { false }
    }

    private val main = Handler(Looper.getMainLooper())
    private var box: FrameLayout? = null
    private var web: WebView? = null
    private var kind = Kind.OTHER
    private var card: String? = null
    private var openedUrl: String? = null
    private var openedAt = 0L
    private var firstFinish = false
    private var closing = false
    private var timerLabel: TextView? = null
    private var lastOpen: Pair<String, Long>? = null
    private var googleHits = mutableListOf<Long>()
    private var posted = false
    // D2 preload: hidden WebViews for the like / repost buttons currently visible
    private val preloaded = linkedMapOf<String, WebView>()
    /** v2.4.7 Fix 2: the current Like / Repost page loads hidden (slider at 0 s). */
    private var hidden = false
    /** v2.4.7 Fix 6e: a ready WebView (same settings, JS interface, start script) for the next overlay. */
    private var spare: WebView? = null
    private var destroyed = false
    /** v2.4.7 Fix 6f: WebViews whose X hook runs as a document-start script (no manual injection needed). */
    private val startScripted = java.util.WeakHashMap<WebView, Boolean>()
    /** v2.4.7 Fix 6f: the page (url) the X hook was last injected into, per WebView. */
    private val hookedPage = java.util.WeakHashMap<WebView, String>()
    /** v2.4.7 Fix 6c: pages of this overlay whose cookies were already saved; last flush. */
    private val snapped = mutableSetOf<String>()
    private var lastFlushAt = 0L
    private var startedAt = 0L
    /** v2.0.2 safety: the overlay page shows a Cloudflare / human-verification page: it stays open and visible. */
    private var challenge = false
    private val cfKey = "links-" + System.identityHashCode(this)

    init {
        // v2.4.7 Fix 6e: warm a spare WebView once the claim screen is up
        main.post { prepareSpare() }
    }

    val isOpen get() = box != null
    /** v2.4.3: called after a real close (not when one overlay replaces another): kind, page loaded or not. */
    var onClosed: ((Kind, Boolean) -> Unit)? = null

    private fun kindName(k: Kind) = when (k) { Kind.LIKE -> "like"; Kind.REPOST -> "repost"; Kind.FOLLOW -> "follow"; Kind.POST -> "post"; else -> "visit" }
    private fun zealyUrl() = try { zealy()?.url } catch (_: Exception) { null }

    // v2.4.7 Fix 6b: from the in-memory prefs, never the file
    private fun prefs() = try { DbStore.prefs() } catch (_: Exception) { JSONObject() }
    /** Like / Repost auto-close seconds, 0..5 (0 = hidden load). */
    private fun likeCloseSec() = prefs().optInt("likeCloseSec", 3).coerceIn(0, 5)
    private fun on(k: String, def: Boolean = true) = prefs().optBoolean(k, def)
    private fun dp(v: Int) = (v * act.resources.displayMetrics.density).toInt()
    private fun log(m: String) = EventLog.add("links", m)
    private fun toast(t: String) = Toast.makeText(act, t, Toast.LENGTH_LONG).show()

    /** Entry point for every outside link from the Zealy page (JS bridge, onCreateWindow, shouldOverrideUrlLoading). */
    fun open(url: String, cardId: String?) {
        val tap = System.currentTimeMillis()
        val now = SystemClock.uptimeMillis()
        lastOpen?.let { (u, at) -> if (u == url && now - at < 1500) return } // same link reported twice (anchor + window.open)
        lastOpen = url to now
        val u = Uri.parse(url)
        val scheme = u.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") { openScheme(url); return }
        // Telegram / Discord links go straight to their app (no web page first, no "open in app?" question)
        if (openChatApp(u)) return
        if (!on("featInAppLinks")) {
            log("in-app links off: $url sent to the browser")
            try { act.startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
            return
        }
        var k = classify(url)
        if ((k == Kind.LIKE || k == Kind.REPOST) && !on("featLikeTimer")) k = Kind.OTHER
        if (k == Kind.POST && !on("featPostSheet")) k = Kind.OTHER
        if (k == Kind.FOLLOW && !on("featFollowSheet")) k = Kind.OTHER
        close(silent = true)
        kind = k
        hidden = (k == Kind.LIKE || k == Kind.REPOST) && likeCloseSec() == 0
        tapAt = tap
        snapped.clear()
        card = cardId?.ifEmpty { null }
        openedUrl = url
        openedAt = System.currentTimeMillis()
        firstFinish = false
        closing = false
        posted = false
        log("captured ${k.name.lowercase()} link: ${Redact.path(url)}${if (card != null) " (card $card)" else ""}")
        try { EngagedLab.overlayEvent(act, "open", kindName(k), url, zealyUrl()) } catch (_: Exception) {}
        // v2.4.4: Zealy's page saves a Like / Repost / Follow click only after it sees you leave (blur) and come back
        // (focus) at least 1.5 s later. The overlay is on the same screen, so tell the page you left.
        zealy()?.evaluateJavascript("window.__qpOverlayOpened&&window.__qpOverlayOpened()", null)
        // v2.4.3: an X button tapped on a quest page tells us the task's post / profile: keep it for Pre-click
        if (k == Kind.LIKE || k == Kind.REPOST || k == Kind.FOLLOW || k == Kind.POST) {
            val page = zealyUrl()
            val ctx = act.applicationContext
            Thread { try { PageLinks.fromPage(ctx, page, listOf(url to kindName(k)), trusted = true) } catch (_: Exception) {} }.start()
        }
        // v2.4.1: only reply / tweet / quote use the 65% sheet; Follow is full screen with the back arrow.
        // v2.4.7: slider at 0 s: a hidden 1 px box instead of the full-screen overlay.
        if (hidden) buildHidden() else if (k == Kind.POST) buildSheet() else buildFull()
        if (k == Kind.FOLLOW) timerLabel?.text = "closes when you follow"
        val pre = takePreloaded(url)
        val w = pre ?: takeSpare() ?: newWeb()
        attach(w)
        if (hidden) startHiddenClose()
        startedAt = 0L
        if (w.url == null) w.loadUrl(url) else { log("preloaded page swapped in"); onFinished(w, w.url ?: url) }
    }

    // ------------------------------------------------------------------ layout

    private fun buildFull() {
        val b = FrameLayout(act).apply { setBackgroundColor(Color.parseColor("#0b0b0f")); isClickable = true }
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#151519")); setPadding(dp(4), 0, dp(12), 0)
        }
        val back = ImageButton(act).apply {
            setImageResource(R.drawable.ic_qp_back); setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Back"; setOnClickListener { close() }
        }
        val title = TextView(act).apply { setTextColor(Color.parseColor("#c9c9d1")); textSize = 13f; maxLines = 1; text = Uri.parse(openedUrl).host ?: "" }
        timerLabel = TextView(act).apply { setTextColor(Color.parseColor("#e05aae")); textSize = 13f; typeface = Typeface.MONOSPACE }
        bar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(timerLabel)
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)))
        col.addView(FrameLayout(act).apply { tag = "webslot" }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        b.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(b, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box = b
    }

    /** 65% bottom sheet over the Zealy page. Root padding follows the keyboard, so the composer stays above it. */
    private fun buildSheet() {
        val b = FrameLayout(act).apply { setBackgroundColor(Color.parseColor("#66000000")); isClickable = true }
        val sheet = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.parseColor("#0b0b0f")); cornerRadii = floatArrayOf(dp(14).toFloat(), dp(14).toFloat(), dp(14).toFloat(), dp(14).toFloat(), 0f, 0f, 0f, 0f) }
            clipToOutline = true
        }
        val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(6), dp(6), dp(6)) }
        val title = TextView(act).apply {
            setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
            text = if (kind == Kind.FOLLOW) "Follow on X · tap Follow yourself" else "Post on X · the link is pasted when it's sent"
        }
        timerLabel = TextView(act).apply { setTextColor(Color.parseColor("#9a9aa5")); textSize = 12f }
        val done = TextView(act).apply {
            text = "Done"; setTextColor(Color.parseColor("#e05aae")); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(8), dp(12), dp(8)); setOnClickListener { log("sheet closed with Done"); close() }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(timerLabel)
        bar.addView(done)
        sheet.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        sheet.addView(FrameLayout(act).apply { tag = "webslot" }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (root.height * 0.65f).toInt().coerceAtLeast(dp(320)), Gravity.BOTTOM)
        b.addView(sheet, lp)
        // keep the sheet at 65% of the screen, but never taller than the space left above the keyboard
        val full = root.height
        b.addOnLayoutChangeListener { v, _, top, _, bottom, _, _, _, _ ->
            val want = minOf((full * 0.65f).toInt(), bottom - top)
            if (want > 0 && sheet.layoutParams.height != want) { sheet.layoutParams.height = want; v.post { sheet.requestLayout() } }
        }
        root.addView(b, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box = b
    }

    /**
     * v2.4.7 Fix 2: slider at 0 s. The same kind of box the overlay uses (so close() stays the same), but 1 px,
     * almost transparent, behind the Zealy page (index 0), not touchable, not focusable, no back arrow.
     */
    private fun buildHidden() {
        val b = FrameLayout(act).apply {
            alpha = 0.01f; isClickable = false; isFocusable = false; isFocusableInTouchMode = false
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }
        b.addView(FrameLayout(act).apply { tag = "webslot" }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(b, 0, FrameLayout.LayoutParams(1, 1))
        box = b
        timerLabel = null
    }

    /**
     * v2.4.7 Fix 2: the stand-in window stays "open" until the X page finished loading, at least 1.6 s (Zealy
     * needs that time away) and at most 4 s. Then the normal close().
     */
    private fun startHiddenClose() {
        val owner = web
        val t0 = SystemClock.uptimeMillis()
        fun check() {
            if (web !== owner || closing || box == null || challenge) return
            val el = SystemClock.uptimeMillis() - t0
            if ((firstFinish && el >= HIDDEN_MIN_MS) || el >= HIDDEN_MAX_MS) {
                log(if (firstFinish) "hidden load (0 s) finished after $hiddenLoadMs ms" else "hidden load (0 s) not finished after $el ms: closed anyway")
                close(); return
            }
            main.postDelayed({ check() }, 100)
        }
        main.postDelayed({ check() }, 100)
    }
    private var hiddenLoadMs = 0L
    /** v2.4.7 Fix 6h: when open() was called (the tap). */
    private var tapAt = 0L

    private fun slot(): FrameLayout? = box?.findViewWithTag("webslot")

    // ------------------------------------------------------------------ WebView

    private fun newWeb(): WebView {
        val w = WebView(act)
        ZealyWeb.configure(w)
        w.settings.setSupportMultipleWindows(false) // target=_blank inside the overlay stays in the overlay
        w.settings.javaScriptCanOpenWindowsAutomatically = false
        w.addJavascriptInterface(XBridge(w), "QPX")
        if (addStartScript(w, X_HOOK_JS, setOf("https://x.com", "https://twitter.com", "https://mobile.x.com", "https://mobile.twitter.com"))) startScripted[w] = true
        return w
    }

    /** v2.4.7 Fix 6e: one unused WebView kept ready (never loads anything until it is used). */
    private fun prepareSpare() {
        if (destroyed || spare != null || act.isFinishing) return
        try { spare = newWeb() } catch (_: Exception) {}
    }

    private fun takeSpare(): WebView? = spare?.also { spare = null }

    /**
     * v2.4.7 Fix 6f: X hook once per page. With the document-start script it is never injected by hand; without
     * it, once per page at the first onPageFinished of that page.
     */
    private fun hookOnce(view: WebView, url: String) {
        if (startScripted[view] == true || !isX(Uri.parse(url))) return
        val page = url.substringBefore('#')
        if (hookedPage[view] == page) return
        hookedPage[view] = page
        view.evaluateJavascript(X_HOOK_JS, null)
    }

    /** v2.4.7 Fix 6c: CookieManager.flush() at most every 10 s (and always on close / pause). */
    private fun flushMaybe() {
        val now = SystemClock.uptimeMillis()
        if (now - lastFlushAt < 10_000L) return
        lastFlushAt = now
        CookieManager.getInstance().flush()
    }

    /** v2.4.7 Fix 6c: logins of the page saved off the main thread. */
    private fun snapshotBg(url: String?) {
        if (url == null) return
        val ctx = act.applicationContext
        snapshotExec.execute { try { SiteCookies.snapshot(ctx, url) } catch (_: Exception) {} }
    }

    private fun attach(w: WebView) {
        (w.parent as? ViewGroup)?.removeView(w)
        w.alpha = 1f
        w.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView, title: String?) {
                if (view === web && CfChallenge.isChallengeTitle(title)) main.post { surfaceChallenge(view, "page title") }
            }
        }
        w.webViewClient = object : WebViewClient() {
            override fun onReceivedHttpError(view: WebView, req: WebResourceRequest, resp: android.webkit.WebResourceResponse) {
                if (view === web && req.isForMainFrame && CfChallenge.isMitigated(resp)) main.post { surfaceChallenge(view, "cf-mitigated ${resp.statusCode}") }
            }

            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url
                val s = u.scheme?.lowercase()
                if (s == "http" || s == "https" || s == "about" || s == "blob" || s == "data") { googleCheck(u); return false }
                openScheme(u.toString())
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                if (view !== web) return
                if (CfChallenge.isChallengeUrl(url)) main.post { surfaceChallenge(view, "challenge URL") }
                val ms = System.currentTimeMillis() - openedAt
                log("load start ${Redact.path(url)} +$ms ms")
                // v2.4.7 Fix 6h: tap -> page start (from open())
                if (startedAt == 0L) { startedAt = SystemClock.uptimeMillis(); EventLog.add("perf", "overlay ${kind.name.lowercase()}${if (hidden) " (hidden)" else ""}: tap -> page start ${System.currentTimeMillis() - tapAt} ms") }
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (view !== web) return
                view.evaluateJavascript(CfChallenge.DETECT_JS) { res ->
                    if (view !== web) return@evaluateJavascript
                    if (CfChallenge.parse(res)) surfaceChallenge(view, "page content")
                    else if (challenge && !CfChallenge.isChallengeUrl(view.url)) challengeCleared()
                }
                onFinished(view, url)
            }
        }
        slot()?.addView(w, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web = w
    }

    private fun onFinished(view: WebView, url: String) {
        // v2.4.7 Fix 6c: cookies saved once per page (first finish), off the main thread; flush throttled
        val page = url.substringBefore('#')
        if (snapped.add(page)) { flushMaybe(); snapshotBg(url) }
        hookOnce(view, url)
        if (firstFinish) return
        firstFinish = true
        val ms = System.currentTimeMillis() - openedAt
        log("load finish ${Redact.path(url)} +$ms ms")
        // v2.4.7 Fix 6h: page start -> first finish
        EventLog.add("perf", "overlay ${kind.name.lowercase()}${if (hidden) " (hidden)" else ""}: page start -> first finish ${if (startedAt > 0) "${SystemClock.uptimeMillis() - startedAt} ms" else "(preloaded page)"}, tap -> finish ${System.currentTimeMillis() - tapAt} ms")
        if (hidden) { hiddenLoadMs = ms; return } // closed by startHiddenClose()
        if (kind == Kind.LIKE || kind == Kind.REPOST) startAutoClose()
    }

    /** D2: close N seconds after the like / repost page finished loading (N from the Debug slider, 1-5 s, default 3). */
    private fun startAutoClose() {
        val n = likeCloseSec().coerceIn(1, 5)
        val end = SystemClock.uptimeMillis() + n * 1000L
        val owner = web
        fun tick() {
            if (web !== owner || closing || challenge) return
            val left = end - SystemClock.uptimeMillis()
            if (left <= 0) { log("${kind.name.lowercase()} overlay auto-closed after $n s"); close(); return }
            timerLabel?.text = "closes in ${(left + 999) / 1000} s"
            main.postDelayed({ tick() }, 200)
        }
        tick()
    }

    /**
     * v2.0.2 safety: X (or any linked site) shows a Cloudflare / human-verification page. The overlay is made
     * visible (a hidden 0 s load becomes the full-screen overlay), brought to the front, and its auto-close timers
     * stop, so you can solve it right away. Nothing is solved or bypassed for you.
     */
    private fun surfaceChallenge(view: WebView, where: String) {
        if (destroyed || closing || view !== web || challenge) return
        challenge = true
        CfChallenge.shown(cfKey, "link overlay, $where")
        log("human verification page in the overlay ($where): kept open and in front")
        if (hidden) {
            box?.let { root.removeView(it) }
            box = null
            hidden = false
            buildFull()
            (view.parent as? ViewGroup)?.removeView(view)
            view.alpha = 1f
            slot()?.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        box?.let { root.bringChildToFront(it); it.requestFocus() }
        view.requestFocus()
        timerLabel?.text = "verify you're human"
        toast("Human verification required – complete it in this window.")
    }

    private fun challengeCleared() {
        if (!challenge) return
        challenge = false
        CfChallenge.cleared(cfKey, "link overlay")
        timerLabel?.text = if (kind == Kind.FOLLOW) "closes when you follow" else ""
        log("human verification done in the overlay")
    }

    fun close(silent: Boolean = false) {
        val b = box ?: return
        if (challenge) { challenge = false; CfChallenge.cleared(cfKey, "link overlay closed") }
        closing = true
        if (!silent) log("overlay closed (${kind.name.lowercase()}) after ${System.currentTimeMillis() - openedAt} ms")
        val closedKind = kind
        val wasLoaded = firstFinish
        if (!silent) try { EngagedLab.overlayEvent(act, "close", kindName(closedKind), openedUrl ?: "", zealyUrl()) } catch (_: Exception) {}
        CookieManager.getInstance().flush()
        lastFlushAt = SystemClock.uptimeMillis()
        web?.let { snapshotBg(it.url); (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        web = null
        root.removeView(b)
        box = null
        timerLabel = null
        hidden = false
        zealy()?.evaluateJavascript("window.__qpOverlayClosed&&window.__qpOverlayClosed()", null)
        if (!silent) onClosed?.invoke(closedKind, wasLoaded)
        // v2.4.7 Fix 6e: a fresh spare for the next overlay, after this close settled
        if (!destroyed) main.postDelayed({ prepareSpare() }, 400)
    }

    fun onBack(): Boolean {
        if (!isOpen) return false
        // v2.4.7: during a hidden load (0 s) Back ends it early through the same close() as a visible overlay
        val w = web
        if (kind == Kind.OTHER && w != null && w.canGoBack()) { w.goBack(); return true }
        close()
        return true
    }

    fun destroy() {
        destroyed = true
        close(silent = true)
        preloaded.values.forEach { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        preloaded.clear()
        spare?.destroy(); spare = null
        main.removeCallbacksAndMessages(null)
    }

    // ------------------------------------------------------------------ app links / Google

    private val TELEGRAM_APPS = listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.telegram.plus", "org.thunderdog.challegram")
    private val DISCORD_APPS = listOf("com.discord")

    /** t.me/<name>, t.me/+<invite>, t.me/joinchat/<invite>, t.me/<name>/<post>, t.me/c/<chat>/<post> as a tg:// link. */
    private fun telegramDeepLink(u: Uri): String? {
        val segs = (u.pathSegments ?: emptyList()).filter { it.isNotEmpty() }
        val first = segs.firstOrNull() ?: return null
        val start = u.getQueryParameter("start")?.let { "&start=" + Uri.encode(it) } ?: ""
        return when {
            first.equals("joinchat", true) && segs.size >= 2 -> "tg://join?invite=" + Uri.encode(segs[1])
            first.startsWith("+") && first.length > 1 -> "tg://join?invite=" + Uri.encode(first.substring(1))
            first.equals("c", true) && segs.size >= 3 && segs[1].all(Char::isDigit) && segs[2].all(Char::isDigit) ->
                "tg://privatepost?channel=${segs[1]}&post=${segs[2]}"
            first.equals("addstickers", true) && segs.size >= 2 -> "tg://addstickers?set=" + Uri.encode(segs[1])
            first.lowercase() in setOf("share", "login", "proxy", "socks", "setlanguage", "iv", "s") -> null
            Regex("^[A-Za-z0-9_]{3,64}$").matches(first) -> {
                val post = segs.getOrNull(1)?.takeIf { it.isNotEmpty() && it.all(Char::isDigit) }?.let { "&post=$it" } ?: ""
                "tg://resolve?domain=$first$post$start"
            }
            else -> null
        }
    }

    /** Tries each installed app package in turn; false when none of them is installed / accepts the link. */
    private fun startInApp(uri: Uri, packages: List<String>): Boolean {
        for (pkg in packages) {
            try {
                act.startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addCategory(Intent.CATEGORY_BROWSABLE))
                return true
            } catch (_: Exception) { /* not installed: next one */ }
        }
        return false
    }

    /**
     * Telegram and Discord links open in their own app at once. Not installed (or the link has no app form):
     * false, and the link opens in QuestPilot's page like before.
     */
    private fun openChatApp(u: Uri): Boolean {
        val host = u.host?.lowercase()?.removePrefix("www.") ?: return false
        val ok = when {
            host == "t.me" || host == "telegram.me" || host == "telegram.dog" ->
                telegramDeepLink(u)?.let { startInApp(Uri.parse(it), TELEGRAM_APPS) } ?: false
            host == "discord.gg" || host == "discord.com" || host == "discordapp.com" -> {
                val path = u.path ?: ""
                (host == "discord.gg" && path.length > 1 || path.startsWith("/invite/") || path.startsWith("/channels/")) && startInApp(u, DISCORD_APPS)
            }
            else -> false
        }
        if (ok) log("opened ${if (host.contains("discord")) "Discord" else "Telegram"} app directly: ${Redact.path(u.toString())}")
        return ok
    }

    /** intent:// and app deep links only leave the app when their scheme is in Settings > Allowed app links. */
    fun openScheme(url: String) {
        val allowed = prefs().optString("allowedAppLinks", "").split(",", " ", ";").map { it.trim().lowercase().removeSuffix("://").removeSuffix(":") }.filter { it.isNotEmpty() }.toSet()
        val scheme = Uri.parse(url).scheme?.lowercase() ?: return
        if (scheme == "intent") {
            val i = try { Intent.parseUri(url, Intent.URI_INTENT_SCHEME) } catch (_: Exception) { null }
            if (i != null && "intent" in allowed) {
                i.addCategory(Intent.CATEGORY_BROWSABLE); i.component = null; i.selector = null
                try { act.startActivity(i); log("intent:// opened outside (allowed)"); return } catch (_: Exception) {}
            }
            val fb = i?.getStringExtra("browser_fallback_url")
            if (fb != null && fb.startsWith("http")) { log("intent:// -> fallback page in app"); open(fb, card); return }
            toast("Blocked an app link (intent://). Allow \"intent\" under Settings > Allowed app links to open it.")
            log("blocked intent:// link")
            return
        }
        if (scheme in allowed) {
            try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE)); log("$scheme: link opened outside (allowed)"); return } catch (_: Exception) {}
        }
        log("blocked $scheme: link")
        toast("Blocked an app link ($scheme:). Add \"$scheme\" under Settings > Allowed app links to open it in its app.")
    }

    /** C6: Google refuses sign-in in embedded WebViews. Say so clearly instead of looping. */
    private fun googleCheck(u: Uri) {
        if (u.host?.lowercase() != "accounts.google.com") return
        val now = System.currentTimeMillis()
        googleHits.add(now); googleHits.removeAll { now - it > 60_000 }
        val rejected = u.toString().contains("disallowed_useragent") || (u.path ?: "").contains("/rejected")
        if (rejected || googleHits.size >= 6) {
            googleHits.clear()
            web?.stopLoading()
            showGoogleMessage(act, u.toString())
        }
    }

    // ------------------------------------------------------------------ D2 preload (optional, Debug switch)

    fun preloadVisible(urls: List<String>) {
        if (!on("featLikePreload", false) || !on("featLikeTimer")) { if (preloaded.isNotEmpty()) dropPreloads(); return }
        val want = urls.filter { classify(it) == Kind.LIKE || classify(it) == Kind.REPOST }.take(3).toSet()
        preloaded.keys.filter { it !in want }.forEach { k -> preloaded.remove(k)?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() } }
        for (u in want) if (!preloaded.containsKey(u)) {
            val w = newWeb()
            w.alpha = 0.01f
            w.webViewClient = WebViewClient()
            // 1 px, almost transparent, attached to the window so it renders fully
            root.addView(w, 0, FrameLayout.LayoutParams(1, 1))
            w.loadUrl(u)
            preloaded[u] = w
            log("preloading ${Redact.path(u)}")
        }
    }

    private fun takePreloaded(url: String): WebView? = preloaded.remove(url)?.also { (it.parent as? ViewGroup)?.removeView(it) }
    private fun dropPreloads() { preloaded.values.forEach { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }; preloaded.clear() }

    // ------------------------------------------------------------------ D3 / D4 signals from X

    inner class XBridge(private val owner: WebView) {
        @JavascriptInterface fun req(path: String, status: String) = EventLog.add("x-req", "$path -> $status")

        @JavascriptInterface fun posted(id: String, handle: String) = main.post {
            if (owner !== web || kind != Kind.POST || posted) return@post
            val clean = handle.trim().removePrefix("@")
            val link = if (clean.matches(Regex("^[A-Za-z0-9_]{1,15}$"))) "https://x.com/$clean/status/$id" else "https://x.com/i/status/$id"
            onPostSuccess(link, "CreateTweet")
        }

        @JavascriptInterface fun postFailed(why: String, b: String) = main.post {
            if (owner !== web) return@post
            log("post failed: $why (sheet stays open)")
            this@LinkOverlay.toast("X didn't accept the post: the sheet stays open.")
        }

        @JavascriptInterface fun toast(link: String, text: String) = main.post {
            if (owner !== web || kind != Kind.POST || posted) return@post
            if (link.contains("/status/")) onPostSuccess(link.substringBefore('?'), "toast")
            else {
                log("\"$text\" seen but no link in it")
                (act as? LinkBannerHost)?.showLinkBanner(null, "Your post was sent. Copy its link from X and paste it into the task.")
            }
        }

        @JavascriptInterface fun engaged(path: String, b: String) = log("X confirmed ${path.substringAfterLast('/')}")

        @JavascriptInterface fun followed(src: String, b: String) = main.post {
            if (owner !== web || kind != Kind.FOLLOW) return@post
            log("follow detected (source: api)"); close()
        }

        @JavascriptInterface fun following(src: String, b: String) = main.post {
            if (owner !== web || kind != Kind.FOLLOW) return@post
            log("follow detected (source: button${if (src == "text") ", Following text" else ""}), already following or just followed"); close()
        }
    }

    private fun onPostSuccess(link: String, via: String) {
        posted = true
        act.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Post link", link))
        log("post success via $via: ${Redact.path(link)}, copied")
        val c = card
        close() // immediately, no delay
        val z = zealy() ?: return
        val js = "window.__qpPaste?window.__qpPaste(${JSONObject.quote(c ?: "")},${JSONObject.quote(link)}):'none'"
        z.evaluateJavascript(js) { r ->
            val res = r?.trim('"') ?: "none"
            log("paste into card ${c ?: "(none)"}: $res")
            if (res == "none") (act as? LinkBannerHost)?.showLinkBanner(link, "Link copied. Paste it into the task's link field.")
            else Toast.makeText(act, "Post link pasted. Check it, then tap Submit yourself.", Toast.LENGTH_LONG).show()
        }
    }
}

/** C6 message, shared by the overlay and the Zealy login screen. */
fun showGoogleMessage(act: Activity, url: String) {
    EventLog.add("links", "Google sign-in refused in the in-app browser")
    AlertDialog.Builder(act)
        .setTitle("Google sign-in doesn't work here")
        .setMessage("Google blocks sign-in inside apps' built-in browsers. Log in to this site another way (email, X, Discord), or open this one page in your phone's browser.")
        .setPositiveButton("OK", null)
        .setNegativeButton("Open in browser") { _, _ -> try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} }
        .show()
}
