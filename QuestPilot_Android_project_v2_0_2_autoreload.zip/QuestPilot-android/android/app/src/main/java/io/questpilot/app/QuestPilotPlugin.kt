package io.questpilot.app

import android.Manifest
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.ActivityResult
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.ActivityCallback
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

@CapacitorPlugin(
    name = "QuestPilot",
    permissions = [Permission(alias = "notifications", strings = [Manifest.permission.POST_NOTIFICATIONS])],
)
class QuestPilotPlugin : Plugin() {
    companion object {
        @Volatile private var instance: QuestPilotPlugin? = null

        fun emitDbChanged(rev: Long) {
            instance?.notifyListeners("dbChanged", JSObject().put("rev", rev))
        }

        fun emitStatus(ctx: Context) {
            instance?.notifyListeners("statusChanged", status(ctx))
        }

        fun status(ctx: Context): JSObject = JSObject()
            .put("connected", SessionStore.hasSession(ctx))
            .put("sessionExpired", State.sessionExpired)
            .put("userName", State.userName ?: JSONObject.NULL)
            .put("monitoringEnabled", State.monitoringEnabled)
            .put("serviceRunning", MonitorService.running)
            .put("pausedUntil", State.pausedUntil)
            .put("pauseReason", State.pauseReason ?: JSONObject.NULL)
            .put("lastSyncAt", State.lastSyncAt)
            .put("lastQuestPollAt", State.lastQuestPollAt)
            .put("lastMessagePollAt", State.lastMessagePollAt)
            .put("syncing", State.syncing)
            .put("slowFullSync", State.slowFullSync)
            .put("watchText", MonitorService.watchSummary())
            .put("debugBuild", DevTools.ENABLED)
    }

    private val bg = Executors.newCachedThreadPool()

    override fun load() {
        instance = this
    }

    private fun async(call: PluginCall, work: () -> Unit) = bg.execute {
        try { work() } catch (e: Exception) { call.reject(e.message ?: "Error", e) }
    }

    // ---------- data ----------
    @PluginMethod
    fun loadDb(call: PluginCall) = async(call) {
        val (json, rev) = DbStore.load()
        call.resolve(JSObject().put("json", json).put("rev", rev))
    }

    @PluginMethod
    fun saveDb(call: PluginCall) = async(call) {
        val json = call.getString("json") ?: return@async call.reject("json missing")
        val base = call.getData().optLong("baseRev", -1)
        val (ok, out, rev) = DbStore.saveFromUi(json, base)
        call.resolve(JSObject().put("ok", ok).put("conflict", !ok).put("json", out).put("rev", rev))
    }

    // ---------- Zealy session ----------
    @PluginMethod
    fun getStatus(call: PluginCall) = call.resolve(status(context))

    @PluginMethod
    fun connectZealy(call: PluginCall) {
        startActivityForResult(call, Intent(context, ZealyLoginActivity::class.java), "onConnectResult")
    }

    @ActivityCallback
    private fun onConnectResult(call: PluginCall?, result: ActivityResult) {
        call ?: return
        val ok = SessionStore.hasSession(context) && !State.sessionExpired
        call.resolve(JSObject().put("connected", ok))
        emitStatus(context)
    }

    @PluginMethod
    fun disconnectZealy(call: PluginCall) {
        SessionStore.clear(context)
        State.userId = null
        State.userName = null
        State.sessionExpired = false
        MonitorService.stop(context)
        emitStatus(context)
        call.resolve()
    }

    @PluginMethod
    fun syncNow(call: PluginCall) = async(call) {
        // "auto" = started by the app itself (homepage countdown at zero): it waits out a rate-limit pause.
        // A manual "Sync now" still runs, but stops and backs off on 429/403 like every sync.
        // v2.4.2: a manual sync (Sync now, the per-community button, Retry on "no access") passes a pause and
        // ignores the 6-hour "no access" skip, but still goes through the shared request gate.
        val auto = call.getBoolean("auto", false)!!
        val sub = call.getString("subdomain")
        val r = if (auto) ZealySync.syncAll(context, sub, respectPause = true)
        else ZealyGate.manual { ZealySync.syncAll(context, sub) }
        val arr = JSArray()
        r.results.forEach { arr.put(it) }
        call.resolve(JSObject().put("ok", r.ok).put("error", r.error ?: JSONObject.NULL).put("results", arr))
    }

    @PluginMethod
    fun setMonitoring(call: PluginCall) {
        val on = call.getBoolean("enabled", true)!!
        State.monitoringEnabled = on
        if (on) {
            // v2.4.1: no Backoff.ok() here, so switching monitoring on does not erase a rate-limit pause.
            MonitorService.start(context)
        } else MonitorService.stop(context)
        call.resolve(status(context))
        emitStatus(context)
    }

    // ---------- v2.0.2: manual claim run ----------
    /** Start: open the manual run screen now (the ids are saved first when given). */
    @PluginMethod
    fun startManualRun(call: PluginCall) = async(call) {
        val ids = try {
            call.getArray("ids")?.let { a -> (0 until a.length()).map { a.getInt(it) }.filter { it > 0 } }
        } catch (_: Exception) { null }
        if ((ids ?: ManualRun.ids(DbStore.read())).isEmpty()) return@async call.reject("The manual run has no tasks.")
        ManualRun.start(context, ids)
        call.resolve()
    }

    // ---------- open Zealy pages in the signed-in view ----------
    @PluginMethod
    fun openZealy(call: PluginCall) {
        val url = call.getString("url") ?: return call.reject("url missing")
        val i = Intent(context, ClaimActivity::class.java).putExtra(ClaimActivity.EXTRA_URL, url).putExtra(ClaimActivity.EXTRA_MODE, "browse")
        // With a quest id, ClaimActivity autofills that quest's saved content (zealy.io pages only).
        val qid = call.getData().optInt("questId", 0)
        if (qid > 0) i.putExtra(ClaimActivity.EXTRA_QUEST_ID, qid)
        // Claim run: the rest of the list rides along, so the claim screen gets a Next button.
        try {
            val q = call.getArray("queue")
            if (qid > 0 && q != null && q.length() > 1) i.putExtra(ClaimActivity.EXTRA_QUESTS, IntArray(q.length()) { q.getInt(it) })
        } catch (_: Exception) {
        }
        activity.startActivity(i)
        call.resolve()
    }

    /** Saved submissions: store a photo in app storage and return its id. */
    @PluginMethod
    fun savePhoto(call: PluginCall) = async(call) {
        val data = call.getString("data") ?: return@async call.reject("data missing")
        val id = SavedPhotos.save(context, data, call.getString("name") ?: "photo.jpg")
        call.resolve(JSObject().put("id", id))
    }

    // ---------- debug builds only: A1 debug line + test mode (DevTools is a stub in release) ----------
    private fun debugOnly(call: PluginCall): Boolean {
        if (!DevTools.ENABLED) call.unavailable("Not available in release builds")
        return DevTools.ENABLED
    }

    @PluginMethod
    fun getDebugInfo(call: PluginCall) {
        if (debugOnly(call)) async(call) { call.resolve(JSObject.fromJSONObject(DevTools.debugInfo(context))) }
    }

    @PluginMethod
    fun startTestUnlock(call: PluginCall) {
        if (debugOnly(call)) async(call) {
            val q = DevTools.start(context, call.getInt("seconds", 60)!!, call.getData().optInt("sourceQuestId", 0))
            call.resolve(JSObject().put("questId", q.optInt("id")).put("unlockAt", q.optLong("testUnlockAt")))
        }
    }

    @PluginMethod
    fun getTestQuests(call: PluginCall) {
        if (debugOnly(call)) {
            val arr = JSArray()
            DevTools.testQuests(context).forEach { arr.put(it) }
            call.resolve(JSObject().put("quests", arr))
        }
    }

    /** "Clear test data" (debug build). */
    @PluginMethod
    fun clearTest(call: PluginCall) {
        if (debugOnly(call)) async(call) { DevTools.clear(context); call.resolve() }
    }

    /** Debug log screen: request log (cookie values hidden) and "Test connection". */
    @PluginMethod
    fun getNetLog(call: PluginCall) {
        if (debugOnly(call)) call.resolve(JSObject().put("entries", JSArray(NetLog.all().toString())))
    }

    @PluginMethod
    fun clearNetLog(call: PluginCall) {
        if (debugOnly(call)) { NetLog.clear(); call.resolve() }
    }

    @PluginMethod
    fun testConnection(call: PluginCall) {
        if (debugOnly(call)) DevTools.testConnection(context) { call.resolve(JSObject.fromJSONObject(it)) }
    }

    // ---------- v2.4 debug logs (both builds: Settings > Debug & experiments). Secrets are never stored. ----------
    @PluginMethod
    fun getLockedDebug(call: PluginCall) = async(call) { call.resolve(JSObject().put("entries", LockedDebug.all(context))) }

    @PluginMethod
    fun clearLockedDebug(call: PluginCall) = async(call) { LockedDebug.clear(context); call.resolve() }

    @PluginMethod
    fun getEventLog(call: PluginCall) = async(call) { call.resolve(JSObject().put("entries", EventLog.all())) }

    @PluginMethod
    fun clearEventLog(call: PluginCall) = async(call) { EventLog.clear(); call.resolve() }

    /** Scheduled alarms (kind, fire time, quests) for the Debug screen. */
    @PluginMethod
    fun simulateZealy(call: PluginCall) {
        if (!DevTools.ENABLED) return call.reject("debug builds only")
        ZealySimulator.set(call.getInt("code", 0)!!, call.getBoolean("challenge", false)!!, call.getString("match") ?: "", call.getInt("count", 0)!!)
        call.resolve()
    }

    // ---------- v2.4.3 pre-click ----------
    /** Opens the X link for one Pre-click button (like | repost | follow) in the in-app X overlay. */
    @PluginMethod
    fun preclick(call: PluginCall) {
        val url = call.getString("url") ?: return call.reject("url missing")
        val kind = call.getString("kind") ?: return call.reject("kind missing")
        val qid = call.getData().optInt("questId", 0)
        val host = try { android.net.Uri.parse(url).host?.lowercase()?.removePrefix("www.") } catch (_: Exception) { null }
        val base = kind.substringBefore('-') // "follow-2": second Follow button of the task
        if (base !in setOf("like", "repost", "follow", "visit") || qid <= 0) return call.reject("bad pre-click request")
        val scheme = try { android.net.Uri.parse(url).scheme?.lowercase() } catch (_: Exception) { null }
        if (scheme != "https" && scheme != "http") return call.reject("not a web link")
        if (base != "visit" && host != "x.com" && host != "twitter.com" && host != "mobile.twitter.com") return call.reject("not an X link")
        if (host?.endsWith("zealy.io") == true) return call.reject("Zealy links open on the task itself")
        val i = Intent(context, ClaimActivity::class.java).putExtra(ClaimActivity.EXTRA_URL, url).putExtra(ClaimActivity.EXTRA_MODE, "preclick")
            .putExtra(ClaimActivity.EXTRA_QUEST_ID, qid).putExtra(ClaimActivity.EXTRA_PRECLICK_KIND, kind)
        val ctx = context
        // v2.0.0: Like / Repost with the close slider at 0 s: loaded hidden on this screen (1 px, behind the app,
        // not touchable), no claim screen opens. Same hidden load as on the Zealy task page.
        val hidden = (base == "like" || base == "repost") && hiddenLikeLoad()
        // v2.4.6: marked the moment you press (the button you pressed only), then the page opens
        Thread {
            // v2.0.0: Zealy's task id for this button missing or from an earlier period: loaded right now (one
            // request through the shared gate, like Find link), before the press is marked. A repeating task
            // whose post changed with the reset opens today's post.
            val ready = try { PreclickIds.ensure(ctx, qid, base, url) } catch (_: Exception) { PreclickIds.Ready(url, null) }
            val openUrl = ready.url
            val (flag, note) = try { Preclick.onPress(ctx, qid, kind, openUrl, ready.why) } catch (e: Exception) { "none" to (e.message ?: "error") }
            val opened = Intent(i).putExtra(ClaimActivity.EXTRA_URL, openUrl)
            activity.runOnUiThread {
                try { if (hidden) openHidden(openUrl) else activity.startActivity(opened) } catch (_: Exception) {}
            }
            call.resolve(JSObject().put("flag", flag).put("note", note))
        }.start()
    }

    /** v2.0.0: in-app links on, Like / Repost timer on, slider at 0 s. */
    private fun hiddenLikeLoad(): Boolean {
        val p = DbStore.prefs()
        return p.optBoolean("featInAppLinks", true) && p.optBoolean("featLikeTimer", true) &&
            p.optInt("likeCloseSec", 3).coerceIn(0, 5) == 0
    }

    private var hiddenLinks: LinkOverlay? = null

    private fun openHidden(url: String) {
        val root = activity.findViewById<android.widget.FrameLayout>(android.R.id.content) ?: return
        SiteCookies.restore(activity) // the same saved X login the claim screen puts back
        val lo = hiddenLinks ?: LinkOverlay(activity, root) { null }.also { hiddenLinks = it }
        lo.onClosed = { _, loaded -> EventLog.add("preclick", "task page: hidden load closed (${if (loaded) "page loaded" else "page not loaded"})") }
        EventLog.add("preclick", "task page: Like / Repost loaded hidden (slider 0 s), nothing shown")
        lo.open(url, null)
    }

    override fun handleOnDestroy() {
        try { hiddenLinks?.destroy() } catch (_: Exception) {}
        hiddenLinks = null
        super.handleOnDestroy()
    }

    /**
     * v2.4.4 "Find link": loads one quest's task details (ids, X post link, actions) now. One request, the same
     * one Zealy's quest page makes, through the shared gate (manual).
     */
    @PluginMethod
    fun fetchTaskDetails(call: PluginCall) = async(call) {
        val qid = call.getData().optInt("questId", 0)
        val db = DbStore.read()
        val q = DbStore.quest(db, qid) ?: return@async call.reject("Task not found")
        val zid = q.optString("zealyId").ifEmpty { null } ?: return@async call.reject("This task has no Zealy id")
        val sub = DbStore.community(db, q.optInt("communityId"))?.optString("subdomain")?.ifEmpty { null }
            ?: return@async call.reject("Community not found")
        val r = ZealyGate.manual { TaskDetails.fetchFull(context, sub, zid, q.opt("locked").let { it == true || it == 1 }) }.r
        if (r.code == 429) Backoff.hit(context, 429, "rate limit (429) on task details")
        // v2.4.7: no longer "Waiting for the next sync" once Zealy answered
        if (!r.skipped) try { TaskDetails.markStates(mapOf(zid to null)) } catch (_: Exception) {}
        val links = DbStore.quest(DbStore.read(), qid)?.optJSONArray("pageLinks")?.length() ?: 0
        val n = TaskIds.tasks(context, zid)?.length() ?: 0
        call.resolve(JSObject().put("ok", r.ok).put("code", r.code).put("tasks", n).put("links", links)
            .put("message", when {
                r.ok && links > 0 -> "Found $links link(s) for this task."
                r.ok -> "Zealy answered, but this task has no X / visit link in its settings."
                r.skipped -> "Paused: not sent."
                else -> "Zealy answered ${r.describe()}"
            }))
    }

    /** Debug: engaged cookie watcher, writes seen on Zealy's page, overlay times, learned writes, Match ids. */
    @PluginMethod
    fun getEngaged(call: PluginCall) = async(call) {
        call.resolve(JSObject().put("at", System.currentTimeMillis()).put("cookies", EngagedLab.watcher(context))
            .put("writes", EngagedLab.writes(context)).put("overlay", EngagedLab.overlayEvents(context))
            .put("learned", EngagedLab.observations(context)).put("matches", EngagedLab.matchIds(context))
            .put("stored", EngagedLab.stored(context).length()))
    }

    /** Debug: raw tasks + description kept for quests with an X task / X link, and task ids seen on Zealy's page. */
    @PluginMethod
    fun getRawQuests(call: PluginCall) = async(call) {
        call.resolve(JSObject().put("raw", RawQuests.all(context)).put("taskIds", TaskIds.all(context)))
    }

    @PluginMethod
    fun getZealyRecorder(call: PluginCall) = async(call) { call.resolve(JSObject().put("entries", ZealyRecorder.all(context))) }

    @PluginMethod
    fun clearZealyRecorder(call: PluginCall) = async(call) { ZealyRecorder.clear(context); call.resolve() }

    @PluginMethod
    fun getRequestStats(call: PluginCall) = async(call) {
        call.resolve(JSObject().put("lastMinute", ZealyGate.count(60_000L)).put("last10Minutes", ZealyGate.count(600_000L))
            .put("perMinuteCap", ZealyGate.PER_MINUTE).put("paused", State.paused()).put("pauseReason", State.pauseReason ?: JSONObject.NULL)
            .put("pausedUntil", State.pausedUntil))
    }

    @PluginMethod
    fun getAlarms(call: PluginCall) = async(call) { call.resolve(JSObject().put("entries", AlarmScheduler.entries(context)).put("exactAlarm", AlarmScheduler.canExact(context))) }

    // ---------- C5 logged-in sites ----------
    @PluginMethod
    fun getLoggedInSites(call: PluginCall) = async(call) { call.resolve(JSObject().put("sites", SiteCookies.list(context))) }

    @PluginMethod
    fun logoutSite(call: PluginCall) {
        val site = call.getString("site") ?: return call.reject("site missing")
        activity.runOnUiThread {
            try { SiteCookies.logout(context, site); call.resolve() } catch (e: Exception) { call.reject(e.message ?: "Error") }
        }
    }

    // ---------- permissions (first launch guide) ----------
    private fun permState(): JSObject {
        val ctx = context
        val notif = when {
            Build.VERSION.SDK_INT < 33 -> if (ctx.getSystemService(NotificationManager::class.java).areNotificationsEnabled()) "granted" else "denied"
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED -> "granted"
            else -> "prompt"
        }
        val fsi = Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()
        val battery = ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
        return JSObject().put("sdk", Build.VERSION.SDK_INT).put("manufacturer", Build.MANUFACTURER ?: "")
            .put("notifications", notif).put("exactAlarm", AlarmScheduler.canExact(ctx))
            .put("fullScreenIntent", fsi).put("batteryUnrestricted", battery)
    }

    @PluginMethod
    fun getPermissionState(call: PluginCall) = call.resolve(permState())

    @PluginMethod
    fun requestNotificationPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT < 33 || permState().getString("notifications") == "granted") return call.resolve(permState())
        requestPermissionForAlias("notifications", call, "onNotifPerm")
    }

    @PermissionCallback
    private fun onNotifPerm(call: PluginCall) = call.resolve(permState())

    private fun open(vararg intents: Intent) {
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
    }

    private val pkgUri get() = Uri.parse("package:${context.packageName}")

    @PluginMethod
    fun openExactAlarmSettings(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= 31) open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri), Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
        call.resolve()
    }

    @PluginMethod
    fun openFullScreenIntentSettings(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= 34) open(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkgUri), Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
        call.resolve()
    }

    @PluginMethod
    fun openBatterySettings(call: PluginCall) {
        @Suppress("BatteryLife")
        open(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri),
        )
        call.resolve()
    }

    @PluginMethod
    fun openAutostartSettings(call: PluginCall) {
        val candidates = listOf(
            ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
            ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"),
            ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"),
            ComponentName("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"),
        )
        var opened = false
        for (cn in candidates) {
            try {
                context.startActivity(Intent().setComponent(cn).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                opened = true
                break
            } catch (_: Exception) {
            }
        }
        if (!opened) open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri))
        call.resolve(JSObject().put("opened", opened))
    }

    // ---------- misc ----------
    @PluginMethod
    fun sendTelegramTest(call: PluginCall) = async(call) {
        val (ok, err) = Telegram.send(context, "QuestPilot is connected. Alerts will arrive here.")
        call.resolve(JSObject().put("ok", ok).put("error", err ?: JSONObject.NULL))
    }

    @PluginMethod
    fun shareText(call: PluginCall) {
        val text = call.getString("text") ?: ""
        val name = call.getString("fileName") ?: "questpilot.txt"
        val mime = call.getString("mime") ?: "text/plain"
        val f = File(context.cacheDir, name)
        f.writeText(text)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        activity.startActivity(Intent.createChooser(send, "Add to calendar").putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(view)))
        call.resolve()
    }
}

/**
 * v2.0.0: makes sure the Pre-click button you pressed has Zealy's task id before the press is marked
 * (Preclick.onPress / EngagedLab.write are unchanged; they read the ids this saves).
 */
object PreclickIds {
    class Ready(val url: String, val why: String?)

    private val TYPE = mapOf("like" to "tweetReact", "repost" to "tweetReact", "follow" to "twitterFollow", "visit" to "visitLink")

    private fun settingsOf(t: JSONObject): JSONObject = when (val s = t.opt("settings")) {
        is JSONObject -> s
        is String -> try { JSONObject(s) } catch (_: Exception) { JSONObject() }
        else -> JSONObject()
    }

    private fun tasksOf(ctx: Context, zid: String, type: String): List<JSONObject> {
        val a = TaskIds.tasks(ctx, zid) ?: return emptyList()
        return (0 until a.length()).mapNotNull { a.optJSONObject(it) }.filter { it.optString("id").isNotEmpty() && it.optString("type") == type }
    }

    /** Same choice EngagedLab.write makes: one task of the type, or exactly one matching the link. */
    private fun has(ctx: Context, zid: String, base: String, url: String): Boolean {
        val c = tasksOf(ctx, zid, TYPE[base] ?: return true)
        if (c.size == 1) return true
        if (c.isEmpty()) return false
        val tid = LinkKey.tweetId(url); val h = LinkKey.handle(url); val clean = LinkKey.cleanUrl(url)
        return c.count { t ->
            val s = settingsOf(t)
            when (base) {
                "like", "repost" -> tid != null && LinkKey.tweetId(s.optString("tweetUrl")) == tid
                "follow" -> h != null && s.optString("username").trim().removePrefix("@").equals(h, true)
                else -> PageLinks.visitUrl(s)?.let { LinkKey.cleanUrl(it) } == clean
            }
        } == 1
    }

    fun ensure(ctx: Context, qid: Int, base: String, url: String): Ready {
        val db = DbStore.read()
        val q = DbStore.quest(db, qid) ?: return Ready(url, null)
        val zid = q.optString("zealyId").ifEmpty { null }
            ?: return Ready(url, "Not marked on Zealy: this task was added by hand, so QuestPilot has no Zealy id for it. Sync the community to get it from Zealy.")
        val rec = q.optString("recurrence", "once")
        val e = TaskIds.entry(ctx, zid)
        val ps = UnlockClock.periodStart(rec, System.currentTimeMillis())
        val stale = rec != "once" && ps > 0 && (e?.optLong("at", 0L) ?: 0L) < ps
        if (has(ctx, zid, base, url) && !stale) return Ready(url, null)
        val sub = DbStore.community(db, q.optInt("communityId"))?.optString("subdomain")?.ifEmpty { null } ?: return Ready(url, null)
        val locked = q.opt("locked").let { it == true || it == 1 } || q.optJSONObject("zealy")?.optBoolean("locked") == true
        val f = ZealyGate.manual { TaskDetails.fetchFull(ctx, sub, zid, locked) }
        if (f.r.code == 429) Backoff.hit(ctx, 429, "rate limit (429) on task details")
        if (!f.r.skipped) try { TaskDetails.markStates(mapOf(zid to null)) } catch (_: Exception) {}
        EventLog.add("preclick", "${q.optString("title")}: task ids ${if (stale) "from an earlier period" else "missing"} for $base, loaded right before the press: ${if (f.loaded) "ok" else "HTTP ${f.r.code}"}")
        if (!f.loaded) return Ready(url, "Not marked on Zealy: QuestPilot couldn't load this task's ids from Zealy (${if (f.r.code > 0) "HTTP ${f.r.code}" else "no answer"}). The page opened anyway; tap the button again later.")
        // a repeating task's post changed with the reset: open today's post
        var out = url
        if ((base == "like" || base == "repost") && !has(ctx, zid, base, url)) {
            val c = tasksOf(ctx, zid, "tweetReact")
            val id = c.singleOrNull()?.let { LinkKey.tweetId(settingsOf(it).optString("tweetUrl")) }
            if (id != null) {
                out = "https://x.com/intent/" + (if (base == "like") "like" else "retweet") + "?tweet_id=" + id
                EventLog.add("preclick", "${q.optString("title")}: the post changed, opening today's post instead")
            }
        }
        return Ready(out, null)
    }

    /** Why there is nothing to mark, in plain words (instead of "while locked" on an open task). */
    fun why(ctx: Context, qid: Int, base: String): String {
        val q = DbStore.quest(DbStore.read(), qid) ?: return "Not marked on Zealy: task not found."
        val zid = q.optString("zealyId").ifEmpty { null } ?: return "Not marked on Zealy: this task was added by hand, so QuestPilot has no Zealy id for it."
        val all = TaskIds.tasks(ctx, zid)
        val types = (0 until (all?.length() ?: 0)).mapNotNull { all!!.optJSONObject(it)?.optString("type") }
        val want = TYPE[base] ?: return "Not marked on Zealy."
        return when {
            types.isEmpty() && (q.opt("locked").let { it == true || it == 1 }) ->
                "Not marked on Zealy yet: the task is still locked, so Zealy hasn't given its task id. QuestPilot marks it as soon as the task unlocks. The page opened anyway."
            types.isEmpty() -> "Not marked on Zealy: Zealy hasn't sent this task's details yet. The page opened anyway."
            want !in types -> "Not marked on Zealy: this task has no ${if (base == "visit") "visit" else "X"} step on Zealy (${types.distinct().joinToString(", ")}), so there is nothing to mark. The page opened anyway."
            else -> "Not marked on Zealy: this task has several ${if (base == "visit") "links" else "posts"} and this one isn't in Zealy's task list. The page opened anyway."
        }
    }
}
